package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzedittext extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzedittext", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzedittext.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _tag = null;
public anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _oedittext = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xedittext = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _b4xb4xbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Private Sub b4xb4xBase_Touch (Action As Int, X As";
 //BA.debugLineNum = 73;BA.debugLine="Log(\"Base_Touch==>\")";
__c.LogImpl("617629185","Base_Touch==>",0);
 //BA.debugLineNum = 74;BA.debugLine="Log( Action)";
__c.LogImpl("617629186",BA.NumberToString(_action),0);
 //BA.debugLineNum = 76;BA.debugLine="If b4xBase.TOUCH_ACTION_UP == Action Then";
if (_b4xbase.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 77;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 78;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _b4xedittext_click() throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Private Sub b4xEditText_Click";
 //BA.debugLineNum = 86;BA.debugLine="Log(\"b4xEditText_Click ==>\")";
__c.LogImpl("617694721","b4xEditText_Click ==>",0);
 //BA.debugLineNum = 87;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 88;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _base_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Private Sub Base_Touch (Action As Int, X As Double";
 //BA.debugLineNum = 60;BA.debugLine="Log(\"Base_Touch==>\")";
__c.LogImpl("617563649","Base_Touch==>",0);
 //BA.debugLineNum = 61;BA.debugLine="Log( Action)";
__c.LogImpl("617563650",BA.NumberToString(_action),0);
 //BA.debugLineNum = 63;BA.debugLine="If b4xBase.TOUCH_ACTION_UP == Action Then";
if (_b4xbase.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 64;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 65;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 13;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 14;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 15;BA.debugLine="Public b4xBase As B4XView";
_b4xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 17;BA.debugLine="Public Tag As Object";
_tag = new Object();
 //BA.debugLineNum = 20;BA.debugLine="Private oEditText As TextField";
_oedittext = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private b4xEditText As B4XView";
_b4xedittext = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 41;BA.debugLine="b4xBase = Base";
_b4xbase = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 42;BA.debugLine="Tag = b4xBase.Tag";
_tag = _b4xbase.getTag();
 //BA.debugLineNum = 43;BA.debugLine="b4xBase.Tag = Me";
_b4xbase.setTag(this);
 //BA.debugLineNum = 47;BA.debugLine="oEditText.Initialize(\"oEditText\")";
_oedittext.Initialize(ba,"oEditText");
 //BA.debugLineNum = 48;BA.debugLine="b4xEditText = oEditText";
_b4xedittext = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_oedittext.getObject()));
 //BA.debugLineNum = 49;BA.debugLine="b4xEditText.TextSize = 28";
_b4xedittext.setTextSize(28);
 //BA.debugLineNum = 51;BA.debugLine="b4xBase.AddView(b4xEditText ,0,0,b4xBase.Width,b4";
_b4xbase.AddView((javafx.scene.Node)(_b4xedittext.getObject()),0,0,_b4xbase.getWidth(),_b4xbase.getHeight());
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 35;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 36;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _oedittext_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Private Sub oEditText_MouseClicked (EventData As M";
 //BA.debugLineNum = 98;BA.debugLine="Log(\"oEditText_Click ==>\")";
__c.LogImpl("617760257","oEditText_Click ==>",0);
 //BA.debugLineNum = 99;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 100;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public String  _oedittext_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 107;BA.debugLine="Private Sub oEditText_Touch (Action As Int, X As D";
 //BA.debugLineNum = 108;BA.debugLine="Log(\"oButton_Touch==>\")";
__c.LogImpl("617825793","oButton_Touch==>",0);
 //BA.debugLineNum = 109;BA.debugLine="Log( Action)";
__c.LogImpl("617825794",BA.NumberToString(_action),0);
 //BA.debugLineNum = 112;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 113;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
