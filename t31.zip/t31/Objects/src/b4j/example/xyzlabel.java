package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzlabel extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzlabel", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzlabel.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xtemp = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xparent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xlabel = null;
public anywheresoftware.b4j.objects.LabelWrapper _mlabel = null;
public Object _mtag = null;
public String _mtext = "";
public int _mtextcolor = 0;
public double _mtextsize = 0;
public int _mbackgroundcolor = 0;
public int _mborderwidth = 0;
public int _mbordercolor = 0;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(Object _parent,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Public Sub AddToParent(Parent As Object,  Props As";
 //BA.debugLineNum = 113;BA.debugLine="Log(\"xyzLabel  AddToParent ==>\")";
__c.LogImpl("6393217","xyzLabel  AddToParent ==>",0);
 //BA.debugLineNum = 116;BA.debugLine="b4xParent = Parent";
_b4xparent = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_parent));
 //BA.debugLineNum = 118;BA.debugLine="Try	'傳入的參數.有可能出錯???";
try { //BA.debugLineNum = 119;BA.debugLine="mLeft = Props.Get(\"Left\")";
_mleft = (int)(BA.ObjectToNumber(_props.Get((Object)("Left"))));
 //BA.debugLineNum = 120;BA.debugLine="mTop = Props.Get(\"Top\")";
_mtop = (int)(BA.ObjectToNumber(_props.Get((Object)("Top"))));
 //BA.debugLineNum = 121;BA.debugLine="mWidth = Props.Get(\"Width\")";
_mwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("Width"))));
 //BA.debugLineNum = 122;BA.debugLine="mHeight = Props.Get(\"Height\")";
_mheight = (int)(BA.ObjectToNumber(_props.Get((Object)("Height"))));
 //BA.debugLineNum = 124;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 125;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Props.Get(\"";
_mtextcolor = _xui.PaintOrColorToColor(_props.Get((Object)("TextColor")));
 //BA.debugLineNum = 126;BA.debugLine="mTag = Props.Get(\"Tag\")";
_mtag = _props.Get((Object)("Tag"));
 //BA.debugLineNum = 128;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 129;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 130;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e15) {
			ba.setLastException(e15); //BA.debugLineNum = 133;BA.debugLine="Log(\"xyzLabel AddToParent= \"&LastException)";
__c.LogImpl("6393237","xyzLabel AddToParent= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 137;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 139;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 140;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 143;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return "";
}
public String  _b4xbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 190;BA.debugLine="Private Sub b4xBase_Touch (Action As Int, X As Dou";
 //BA.debugLineNum = 191;BA.debugLine="Log(\"xyzLabel  b4xBase_Touch==>\")";
__c.LogImpl("6589825","xyzLabel  b4xBase_Touch==>",0);
 //BA.debugLineNum = 192;BA.debugLine="Log( Action)";
__c.LogImpl("6589826",BA.NumberToString(_action),0);
 //BA.debugLineNum = 194;BA.debugLine="If b4xBase.TOUCH_ACTION_UP == Action Then";
if (_b4xbase.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 195;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 196;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 177;BA.debugLine="Log(\"xyzLabel  Base_Resize ==>\")";
__c.LogImpl("6524289","xyzLabel  Base_Resize ==>",0);
 //BA.debugLineNum = 178;BA.debugLine="Log(\"xyzLabel  Width= \"&Width)";
__c.LogImpl("6524290","xyzLabel  Width= "+BA.NumberToString(_width),0);
 //BA.debugLineNum = 182;BA.debugLine="b4xLabel.Width = Width";
_b4xlabel.setWidth(_width);
 //BA.debugLineNum = 183;BA.debugLine="b4xLabel.Height = Height";
_b4xlabel.setHeight(_height);
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 20;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 21;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 23;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 25;BA.debugLine="Private b4xTemp As B4XView";
_b4xtemp = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private b4xBase As B4XView";
_b4xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private b4xParent As B4XView";
_b4xparent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private b4xLabel As B4XView";
_b4xlabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private mLabel As Label";
_mlabel = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private mTag As Object		'不懂為何宣告物件???";
_mtag = new Object();
 //BA.debugLineNum = 34;BA.debugLine="Private mText As String";
_mtext = "";
 //BA.debugLineNum = 35;BA.debugLine="Private mTextColor As Int";
_mtextcolor = 0;
 //BA.debugLineNum = 36;BA.debugLine="Private mTextSize As Double";
_mtextsize = 0;
 //BA.debugLineNum = 38;BA.debugLine="Private mBackgroundColor As Int";
_mbackgroundcolor = 0;
 //BA.debugLineNum = 40;BA.debugLine="Private mBorderWidth ,mBorderColor As Int";
_mborderwidth = 0;
_mbordercolor = 0;
 //BA.debugLineNum = 41;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 67;BA.debugLine="Log(\"xyzLabel DesignerCreateView==>\")";
__c.LogImpl("6327681","xyzLabel DesignerCreateView==>",0);
 //BA.debugLineNum = 69;BA.debugLine="Log(\"test1\")";
__c.LogImpl("6327683","test1",0);
 //BA.debugLineNum = 70;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("6327684","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 73;BA.debugLine="b4xTemp = Base				'照論壇上的範例.Base當作暫時的物件";
_b4xtemp = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 76;BA.debugLine="b4xTemp.Visible = False		'我把它隱藏起來.安心";
_b4xtemp.setVisible(__c.False);
 //BA.debugLineNum = 78;BA.debugLine="mLeft = b4xTemp.Left";
_mleft = (int) (_b4xtemp.getLeft());
 //BA.debugLineNum = 79;BA.debugLine="mTop = b4xTemp.Top";
_mtop = (int) (_b4xtemp.getTop());
 //BA.debugLineNum = 80;BA.debugLine="mWidth = b4xTemp.Width";
_mwidth = (int) (_b4xtemp.getWidth());
 //BA.debugLineNum = 81;BA.debugLine="mHeight = b4xTemp.Height";
_mheight = (int) (_b4xtemp.getHeight());
 //BA.debugLineNum = 82;BA.debugLine="mTag = b4xTemp.Tag				'利用原有的屬性.不須另外設定";
_mtag = _b4xtemp.getTag();
 //BA.debugLineNum = 84;BA.debugLine="Try";
try { //BA.debugLineNum = 85;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 86;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Lbl.TextCol";
_mtextcolor = _xui.PaintOrColorToColor((Object)(_lbl.getTextColor()));
 //BA.debugLineNum = 88;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 89;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 90;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e18) {
			ba.setLastException(e18); //BA.debugLineNum = 93;BA.debugLine="Log(\"xyzLabel DesignerCreateView= \"&LastExceptio";
__c.LogImpl("6327707","xyzLabel DesignerCreateView= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 97;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 98;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 102;BA.debugLine="b4xParent = b4xTemp.Parent";
_b4xparent = _b4xtemp.getParent();
 //BA.debugLineNum = 103;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 107;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public int  _getbackgroundcolor() throws Exception{
 //BA.debugLineNum = 254;BA.debugLine="Public Sub getBackgroundColor  As Int";
 //BA.debugLineNum = 255;BA.debugLine="Return mBackgroundColor";
if (true) return _mbackgroundcolor;
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return 0;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 210;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 211;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return null;
}
public String  _gettext() throws Exception{
 //BA.debugLineNum = 224;BA.debugLine="Public Sub getText  As String";
 //BA.debugLineNum = 225;BA.debugLine="Return mText";
if (true) return _mtext;
 //BA.debugLineNum = 226;BA.debugLine="End Sub";
return "";
}
public int  _gettextsize() throws Exception{
 //BA.debugLineNum = 236;BA.debugLine="Public Sub getTextSize  As Int";
 //BA.debugLineNum = 237;BA.debugLine="Return mTextSize";
if (true) return (int) (_mtextsize);
 //BA.debugLineNum = 238;BA.debugLine="End Sub";
return 0;
}
public String  _initclass() throws Exception{
int _lblwidth = 0;
 //BA.debugLineNum = 146;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 147;BA.debugLine="Log(\"xyzLabel  InitClass ==>\")";
__c.LogImpl("6458753","xyzLabel  InitClass ==>",0);
 //BA.debugLineNum = 150;BA.debugLine="Private  lblWidth  As Int";
_lblwidth = 0;
 //BA.debugLineNum = 151;BA.debugLine="lblWidth = 2 * mHeight / 3		'icon Label width and";
_lblwidth = (int) (2*_mheight/(double)3);
 //BA.debugLineNum = 154;BA.debugLine="mTextSize = lblWidth / 3 / xui.Scale";
_mtextsize = _lblwidth/(double)3/(double)_xui.getScale();
 //BA.debugLineNum = 157;BA.debugLine="mLabel.Initialize(\"\")";
_mlabel.Initialize(ba,"");
 //BA.debugLineNum = 158;BA.debugLine="b4xLabel = mLabel";
_b4xlabel = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mlabel.getObject()));
 //BA.debugLineNum = 159;BA.debugLine="b4xLabel.SetTextAlignment(\"CENTER\", \"CENTER\")";
_b4xlabel.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 161;BA.debugLine="b4xLabel.TextSize = mTextSize";
_b4xlabel.setTextSize(_mtextsize);
 //BA.debugLineNum = 162;BA.debugLine="b4xLabel.TextColor = xui.PaintOrColorToColor(mTex";
_b4xlabel.setTextColor(_xui.PaintOrColorToColor((Object)(_mtextcolor)));
 //BA.debugLineNum = 166;BA.debugLine="b4xLabel.Text = mText";
_b4xlabel.setText(_mtext);
 //BA.debugLineNum = 170;BA.debugLine="b4xBase.AddView(b4xLabel, 0, 0 ,b4xBase.Width  ,b";
_b4xbase.AddView((javafx.scene.Node)(_b4xlabel.getObject()),0,0,_b4xbase.getWidth(),_b4xbase.getHeight());
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 44;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 45;BA.debugLine="Log(\"========================>\")";
__c.LogImpl("6262145","========================>",0);
 //BA.debugLineNum = 46;BA.debugLine="Log(\"xyzLabel  Initialize ==>\")";
__c.LogImpl("6262146","xyzLabel  Initialize ==>",0);
 //BA.debugLineNum = 47;BA.debugLine="Log(\"EventName= \"&EventName)";
__c.LogImpl("6262147","EventName= "+_eventname,0);
 //BA.debugLineNum = 49;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 50;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 52;BA.debugLine="mText = \"\"";
_mtext = "";
 //BA.debugLineNum = 54;BA.debugLine="mTextColor = xui.Color_Cyan";
_mtextcolor = _xui.Color_Cyan;
 //BA.debugLineNum = 61;BA.debugLine="mBackgroundColor = xui.Color_Transparent";
_mbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _setbackgroundcolor(int _s1) throws Exception{
 //BA.debugLineNum = 248;BA.debugLine="Public Sub setBackgroundColor(s1 As Int)";
 //BA.debugLineNum = 249;BA.debugLine="Log(\"setBackgroundColor ==>\")";
__c.LogImpl("61114113","setBackgroundColor ==>",0);
 //BA.debugLineNum = 251;BA.debugLine="mBackgroundColor=s1";
_mbackgroundcolor = _s1;
 //BA.debugLineNum = 252;BA.debugLine="If b4xBase.IsInitialized Then b4xBase.Color = mBa";
if (_b4xbase.IsInitialized()) { 
_b4xbase.setColor(_mbackgroundcolor);};
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 205;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 206;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 207;BA.debugLine="b4xBase.Tag = Tag";
_b4xbase.setTag(_tag);
 //BA.debugLineNum = 208;BA.debugLine="End Sub";
return "";
}
public String  _settext(String _s1) throws Exception{
 //BA.debugLineNum = 214;BA.debugLine="Public Sub setText(s1 As String)";
 //BA.debugLineNum = 215;BA.debugLine="Log(\"setText ==>\")";
__c.LogImpl("6786433","setText ==>",0);
 //BA.debugLineNum = 218;BA.debugLine="mText=s1";
_mtext = _s1;
 //BA.debugLineNum = 219;BA.debugLine="b4xLabel.Text = s1";
_b4xlabel.setText(_s1);
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
return "";
}
public String  _settextalignment(String _s1,String _s2) throws Exception{
 //BA.debugLineNum = 260;BA.debugLine="Public Sub SetTextAlignment(s1 As String,s2 As Str";
 //BA.debugLineNum = 262;BA.debugLine="b4xLabel.SetTextAlignment(s1 , s2 )";
_b4xlabel.SetTextAlignment(_s1,_s2);
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return "";
}
public String  _settextcolor(int _s1) throws Exception{
 //BA.debugLineNum = 241;BA.debugLine="Public Sub setTextColor(s1 As Int)";
 //BA.debugLineNum = 242;BA.debugLine="Log(\"setTextColor ==>\")";
__c.LogImpl("61048577","setTextColor ==>",0);
 //BA.debugLineNum = 244;BA.debugLine="mTextColor=s1";
_mtextcolor = _s1;
 //BA.debugLineNum = 245;BA.debugLine="b4xLabel.TextColor = mTextColor";
_b4xlabel.setTextColor(_mtextcolor);
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public String  _settextsize(int _s1) throws Exception{
 //BA.debugLineNum = 229;BA.debugLine="Public Sub setTextSize(s1 As Int)";
 //BA.debugLineNum = 230;BA.debugLine="Log(\"setTextSize ==>\")";
__c.LogImpl("6917505","setTextSize ==>",0);
 //BA.debugLineNum = 232;BA.debugLine="mTextSize=s1";
_mtextsize = _s1;
 //BA.debugLineNum = 233;BA.debugLine="b4xLabel.TextSize = s1";
_b4xlabel.setTextSize(_s1);
 //BA.debugLineNum = 234;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
