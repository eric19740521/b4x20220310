package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_layout1{

public static void LS_general(anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale) {
;
//BA.debugLineNum = 3;BA.debugLine="AutoScaleAll"[Layout1/General script]
;

}
}