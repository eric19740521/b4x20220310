package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzbutton extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzbutton", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzbutton.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xtemp = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xparent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xlabel = null;
public anywheresoftware.b4j.objects.LabelWrapper _mlabel = null;
public Object _mtag = null;
public String _mtext = "";
public int _mtextcolor = 0;
public double _mlabeltextsize = 0;
public int _mpressedcolor = 0;
public int _mbackgroundcolor = 0;
public int _mborderwidth = 0;
public int _mbordercolor = 0;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(Object _parent,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Public Sub AddToParent(Parent As Object,  Props As";
 //BA.debugLineNum = 113;BA.debugLine="Log(\"xyzButton  AddToParent ==>\")";
__c.LogImpl("61507329","xyzButton  AddToParent ==>",0);
 //BA.debugLineNum = 116;BA.debugLine="b4xParent = Parent";
_b4xparent = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_parent));
 //BA.debugLineNum = 118;BA.debugLine="Try	'傳入的參數.有可能出錯???";
try { //BA.debugLineNum = 119;BA.debugLine="mLeft = Props.Get(\"Left\")";
_mleft = (int)(BA.ObjectToNumber(_props.Get((Object)("Left"))));
 //BA.debugLineNum = 120;BA.debugLine="mTop = Props.Get(\"Top\")";
_mtop = (int)(BA.ObjectToNumber(_props.Get((Object)("Top"))));
 //BA.debugLineNum = 121;BA.debugLine="mWidth = Props.Get(\"Width\")";
_mwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("Width"))));
 //BA.debugLineNum = 122;BA.debugLine="mHeight = Props.Get(\"Height\")";
_mheight = (int)(BA.ObjectToNumber(_props.Get((Object)("Height"))));
 //BA.debugLineNum = 124;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 125;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Props.Get(\"";
_mtextcolor = _xui.PaintOrColorToColor(_props.Get((Object)("TextColor")));
 //BA.debugLineNum = 126;BA.debugLine="mTag = Props.Get(\"Tag\")";
_mtag = _props.Get((Object)("Tag"));
 //BA.debugLineNum = 127;BA.debugLine="mPressedColor = xui.PaintOrColorToColor(Props.Ge";
_mpressedcolor = _xui.PaintOrColorToColor(_props.Get((Object)("PressedColor")));
 //BA.debugLineNum = 128;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 129;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 130;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 133;BA.debugLine="Log(\"xyzButton AddToParent= \"&LastException)";
__c.LogImpl("61507349","xyzButton AddToParent= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 137;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 139;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 140;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 143;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return "";
}
public String  _b4xbase_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 191;BA.debugLine="Private Sub b4xBase_Touch(Action As Int, X As Floa";
 //BA.debugLineNum = 192;BA.debugLine="Log(\"xyzButton  b4xBase_Touch==>\")";
__c.LogImpl("61703937","xyzButton  b4xBase_Touch==>",0);
 //BA.debugLineNum = 193;BA.debugLine="Log(\"Action= \"& Action)";
__c.LogImpl("61703938","Action= "+BA.NumberToString(_action),0);
 //BA.debugLineNum = 195;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_b4xbase.TOUCH_ACTION_DOWN,_b4xbase.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 197;BA.debugLine="b4xBase.Color = mPressedColor";
_b4xbase.setColor(_mpressedcolor);
 break; }
case 1: {
 //BA.debugLineNum = 201;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Clic";
if (_xui.SubExists(ba,_mcallback,_meventname+"_Click",(int) (0))) { 
 //BA.debugLineNum = 202;BA.debugLine="CallSubDelayed(mCallBack, mEventName & \"_Click";
__c.CallSubDelayed(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 204;BA.debugLine="b4xBase.Color = mBackgroundColor";
_b4xbase.setColor(_mbackgroundcolor);
 break; }
}
;
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 176;BA.debugLine="Log(\"xyzButton  Base_Resize ==>\")";
__c.LogImpl("61638401","xyzButton  Base_Resize ==>",0);
 //BA.debugLineNum = 177;BA.debugLine="Log(\"xyzButton  Width= \"&Width)";
__c.LogImpl("61638402","xyzButton  Width= "+BA.NumberToString(_width),0);
 //BA.debugLineNum = 180;BA.debugLine="mWidth = Width";
_mwidth = (int) (_width);
 //BA.debugLineNum = 181;BA.debugLine="mHeight = Height";
_mheight = (int) (_height);
 //BA.debugLineNum = 183;BA.debugLine="b4xBase.Width = Width";
_b4xbase.setWidth(_width);
 //BA.debugLineNum = 184;BA.debugLine="b4xBase.Height = Height";
_b4xbase.setHeight(_height);
 //BA.debugLineNum = 186;BA.debugLine="b4xLabel.Width = Width";
_b4xlabel.setWidth(_width);
 //BA.debugLineNum = 187;BA.debugLine="b4xLabel.Height = Height";
_b4xlabel.setHeight(_height);
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 20;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 21;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 23;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 25;BA.debugLine="Private b4xTemp As B4XView";
_b4xtemp = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private b4xBase As B4XView";
_b4xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private b4xParent As B4XView";
_b4xparent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private b4xLabel As B4XView";
_b4xlabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private mLabel As Label";
_mlabel = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private  mTag As Object		'不懂為何宣告物件???";
_mtag = new Object();
 //BA.debugLineNum = 34;BA.debugLine="Private mText As String";
_mtext = "";
 //BA.debugLineNum = 35;BA.debugLine="Private mTextColor As Int";
_mtextcolor = 0;
 //BA.debugLineNum = 36;BA.debugLine="Private mLabelTextSize As Double";
_mlabeltextsize = 0;
 //BA.debugLineNum = 38;BA.debugLine="Private mPressedColor, mBackgroundColor As Int";
_mpressedcolor = 0;
_mbackgroundcolor = 0;
 //BA.debugLineNum = 39;BA.debugLine="Private mBorderWidth ,mBorderColor As Int";
_mborderwidth = 0;
_mbordercolor = 0;
 //BA.debugLineNum = 40;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 68;BA.debugLine="Log(\"xyzButton DesignerCreateView==>\")";
__c.LogImpl("61441793","xyzButton DesignerCreateView==>",0);
 //BA.debugLineNum = 70;BA.debugLine="Log(\"test1\")";
__c.LogImpl("61441795","test1",0);
 //BA.debugLineNum = 71;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("61441796","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 74;BA.debugLine="b4xTemp = Base				'照論壇上的範例.Base當作暫時的物件";
_b4xtemp = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 77;BA.debugLine="b4xTemp.Visible = False		'我把它隱藏起來.安心";
_b4xtemp.setVisible(__c.False);
 //BA.debugLineNum = 79;BA.debugLine="mLeft = b4xTemp.Left";
_mleft = (int) (_b4xtemp.getLeft());
 //BA.debugLineNum = 80;BA.debugLine="mTop = b4xTemp.Top";
_mtop = (int) (_b4xtemp.getTop());
 //BA.debugLineNum = 81;BA.debugLine="mWidth = b4xTemp.Width";
_mwidth = (int) (_b4xtemp.getWidth());
 //BA.debugLineNum = 82;BA.debugLine="mHeight = b4xTemp.Height";
_mheight = (int) (_b4xtemp.getHeight());
 //BA.debugLineNum = 83;BA.debugLine="mTag = b4xTemp.Tag				'利用原有的屬性.不須另外設定";
_mtag = _b4xtemp.getTag();
 //BA.debugLineNum = 85;BA.debugLine="Try";
try { //BA.debugLineNum = 86;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 87;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Lbl.TextCol";
_mtextcolor = _xui.PaintOrColorToColor((Object)(_lbl.getTextColor()));
 //BA.debugLineNum = 88;BA.debugLine="mPressedColor = xui.PaintOrColorToColor(Props.Ge";
_mpressedcolor = _xui.PaintOrColorToColor(_props.Get((Object)("PressedColor")));
 //BA.debugLineNum = 89;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 90;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 91;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e19) {
			ba.setLastException(e19); //BA.debugLineNum = 94;BA.debugLine="Log(\"xyzButton DesignerCreateView= \"&LastExcepti";
__c.LogImpl("61441819","xyzButton DesignerCreateView= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 98;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 99;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 103;BA.debugLine="b4xParent = b4xTemp.Parent";
_b4xparent = _b4xtemp.getParent();
 //BA.debugLineNum = 104;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 108;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public int  _getbackgroundcolor() throws Exception{
 //BA.debugLineNum = 257;BA.debugLine="Public Sub getBackgroundColor  As Int";
 //BA.debugLineNum = 258;BA.debugLine="Return mBackgroundColor";
if (true) return _mbackgroundcolor;
 //BA.debugLineNum = 259;BA.debugLine="End Sub";
return 0;
}
public int  _getheight() throws Exception{
 //BA.debugLineNum = 276;BA.debugLine="Public Sub getHeight  As Int";
 //BA.debugLineNum = 277;BA.debugLine="Return mHeight";
if (true) return _mheight;
 //BA.debugLineNum = 278;BA.debugLine="End Sub";
return 0;
}
public int  _getleft() throws Exception{
 //BA.debugLineNum = 273;BA.debugLine="Public Sub getLeft  As Int";
 //BA.debugLineNum = 274;BA.debugLine="Return mLeft";
if (true) return _mleft;
 //BA.debugLineNum = 275;BA.debugLine="End Sub";
return 0;
}
public int  _getpressedcolor() throws Exception{
 //BA.debugLineNum = 265;BA.debugLine="Public Sub getPressedColor As Int";
 //BA.debugLineNum = 266;BA.debugLine="Return mPressedColor";
if (true) return _mpressedcolor;
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
return 0;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 221;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 222;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return null;
}
public String  _gettext() throws Exception{
 //BA.debugLineNum = 225;BA.debugLine="Public Sub getText  As String";
 //BA.debugLineNum = 226;BA.debugLine="Return mText";
if (true) return _mtext;
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return "";
}
public int  _gettop() throws Exception{
 //BA.debugLineNum = 270;BA.debugLine="Public Sub getTop  As Int";
 //BA.debugLineNum = 271;BA.debugLine="Return mTop";
if (true) return _mtop;
 //BA.debugLineNum = 272;BA.debugLine="End Sub";
return 0;
}
public int  _getwidth() throws Exception{
 //BA.debugLineNum = 279;BA.debugLine="Public Sub getWidth  As Int";
 //BA.debugLineNum = 280;BA.debugLine="Return mWidth";
if (true) return _mwidth;
 //BA.debugLineNum = 281;BA.debugLine="End Sub";
return 0;
}
public String  _initclass() throws Exception{
int _lblwidth = 0;
 //BA.debugLineNum = 146;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 147;BA.debugLine="Log(\"xyzButton  InitClass ==>\")";
__c.LogImpl("61572865","xyzButton  InitClass ==>",0);
 //BA.debugLineNum = 150;BA.debugLine="Private  lblWidth  As Int";
_lblwidth = 0;
 //BA.debugLineNum = 151;BA.debugLine="lblWidth = 2 * mHeight / 3		'icon Label width and";
_lblwidth = (int) (2*_mheight/(double)3);
 //BA.debugLineNum = 154;BA.debugLine="mLabelTextSize = lblWidth / 3 / xui.Scale";
_mlabeltextsize = _lblwidth/(double)3/(double)_xui.getScale();
 //BA.debugLineNum = 157;BA.debugLine="mLabel.Initialize(\"\")";
_mlabel.Initialize(ba,"");
 //BA.debugLineNum = 158;BA.debugLine="b4xLabel = mLabel";
_b4xlabel = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mlabel.getObject()));
 //BA.debugLineNum = 159;BA.debugLine="b4xLabel.SetTextAlignment(\"CENTER\", \"CENTER\")";
_b4xlabel.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 161;BA.debugLine="b4xLabel.TextSize = mLabelTextSize";
_b4xlabel.setTextSize(_mlabeltextsize);
 //BA.debugLineNum = 162;BA.debugLine="b4xLabel.TextColor = xui.PaintOrColorToColor(mTex";
_b4xlabel.setTextColor(_xui.PaintOrColorToColor((Object)(_mtextcolor)));
 //BA.debugLineNum = 166;BA.debugLine="b4xLabel.Text = mText";
_b4xlabel.setText(_mtext);
 //BA.debugLineNum = 170;BA.debugLine="b4xBase.AddView(b4xLabel, 0, 0 ,b4xBase.Width  ,b";
_b4xbase.AddView((javafx.scene.Node)(_b4xlabel.getObject()),0,0,_b4xbase.getWidth(),_b4xbase.getHeight());
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 44;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 45;BA.debugLine="Log(\"========================>\")";
__c.LogImpl("61376257","========================>",0);
 //BA.debugLineNum = 46;BA.debugLine="Log(\"xyzButton  Initialize ==>\")";
__c.LogImpl("61376258","xyzButton  Initialize ==>",0);
 //BA.debugLineNum = 47;BA.debugLine="Log(\"EventName= \"&EventName)";
__c.LogImpl("61376259","EventName= "+_eventname,0);
 //BA.debugLineNum = 49;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 50;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 52;BA.debugLine="mText = \"\"";
_mtext = "";
 //BA.debugLineNum = 54;BA.debugLine="mTextColor = xui.Color_Cyan";
_mtextcolor = _xui.Color_Cyan;
 //BA.debugLineNum = 59;BA.debugLine="mPressedColor = xui.Color_Yellow";
_mpressedcolor = _xui.Color_Yellow;
 //BA.debugLineNum = 61;BA.debugLine="mBackgroundColor = xui.Color_Transparent";
_mbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public String  _setbackgroundcolor(int _s1) throws Exception{
 //BA.debugLineNum = 251;BA.debugLine="Public Sub setBackgroundColor(s1 As Int)";
 //BA.debugLineNum = 252;BA.debugLine="Log(\"setBackgroundColor ==>\")";
__c.LogImpl("62162689","setBackgroundColor ==>",0);
 //BA.debugLineNum = 254;BA.debugLine="mBackgroundColor=s1";
_mbackgroundcolor = _s1;
 //BA.debugLineNum = 255;BA.debugLine="If b4xBase.IsInitialized Then b4xBase.Color = mBa";
if (_b4xbase.IsInitialized()) { 
_b4xbase.setColor(_mbackgroundcolor);};
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _setbordercolor(int _bordercolor) throws Exception{
 //BA.debugLineNum = 290;BA.debugLine="Public Sub setBorderColor(BorderColor As Int)";
 //BA.debugLineNum = 291;BA.debugLine="Log(\"setBorderColor ==>\")";
__c.LogImpl("62752513","setBorderColor ==>",0);
 //BA.debugLineNum = 293;BA.debugLine="mBorderColor = BorderColor";
_mbordercolor = _bordercolor;
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return "";
}
public String  _setborderwidth(int _borderwidth) throws Exception{
 //BA.debugLineNum = 282;BA.debugLine="Public Sub setBorderWidth(BorderWidth As Int)";
 //BA.debugLineNum = 283;BA.debugLine="Log(\"setBorderWidth ==>\")";
__c.LogImpl("62686977","setBorderWidth ==>",0);
 //BA.debugLineNum = 285;BA.debugLine="mBorderWidth = BorderWidth";
_mborderwidth = _borderwidth;
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return "";
}
public String  _setpressedcolor(int _pressedcolor) throws Exception{
 //BA.debugLineNum = 261;BA.debugLine="Public Sub setPressedColor(PressedColor As Int)";
 //BA.debugLineNum = 262;BA.debugLine="mPressedColor = PressedColor";
_mpressedcolor = _pressedcolor;
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 216;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 217;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 218;BA.debugLine="b4xBase.Tag = Tag";
_b4xbase.setTag(_tag);
 //BA.debugLineNum = 219;BA.debugLine="End Sub";
return "";
}
public String  _settext(String _s1) throws Exception{
 //BA.debugLineNum = 229;BA.debugLine="Public Sub setText(s1 As String)";
 //BA.debugLineNum = 230;BA.debugLine="Log(\"setTextSize ==>\")";
__c.LogImpl("61966081","setTextSize ==>",0);
 //BA.debugLineNum = 232;BA.debugLine="mText=s1";
_mtext = _s1;
 //BA.debugLineNum = 233;BA.debugLine="If b4xLabel.IsInitialized Then b4xLabel.Text = s1";
if (_b4xlabel.IsInitialized()) { 
_b4xlabel.setText(_s1);};
 //BA.debugLineNum = 234;BA.debugLine="End Sub";
return "";
}
public String  _settextalignment(String _s1,String _s2) throws Exception{
 //BA.debugLineNum = 301;BA.debugLine="Public Sub SetTextAlignment(s1 As String,s2 As Str";
 //BA.debugLineNum = 303;BA.debugLine="b4xLabel.SetTextAlignment(s1 , s2 )";
_b4xlabel.SetTextAlignment(_s1,_s2);
 //BA.debugLineNum = 304;BA.debugLine="End Sub";
return "";
}
public String  _settextcolor(int _s1) throws Exception{
 //BA.debugLineNum = 244;BA.debugLine="Public Sub setTextColor(s1 As Int)";
 //BA.debugLineNum = 245;BA.debugLine="Log(\"setTextLabel ==>\")";
__c.LogImpl("62097153","setTextLabel ==>",0);
 //BA.debugLineNum = 247;BA.debugLine="mTextColor=s1";
_mtextcolor = _s1;
 //BA.debugLineNum = 248;BA.debugLine="If b4xLabel.IsInitialized Then b4xLabel.TextColor";
if (_b4xlabel.IsInitialized()) { 
_b4xlabel.setTextColor(_mtextcolor);};
 //BA.debugLineNum = 249;BA.debugLine="End Sub";
return "";
}
public String  _settextsize(int _s1) throws Exception{
 //BA.debugLineNum = 236;BA.debugLine="Public Sub setTextSize(s1 As Int)";
 //BA.debugLineNum = 237;BA.debugLine="Log(\"setTextSize ==>\")";
__c.LogImpl("62031617","setTextSize ==>",0);
 //BA.debugLineNum = 240;BA.debugLine="If b4xLabel.IsInitialized Then	b4xLabel.TextSize";
if (_b4xlabel.IsInitialized()) { 
_b4xlabel.setTextSize(_s1);};
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
