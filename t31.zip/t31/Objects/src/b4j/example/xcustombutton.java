package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xcustombutton extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xcustombutton", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xcustombutton.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xbase = null;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public String _mtext = "";
public String _micon = "";
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _xlabelfont = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _xiconfont = null;
public int _mtextcolor = 0;
public double _micontextsize = 0;
public double _mlabeltextsize = 0;
public Object _mtag = null;
public anywheresoftware.b4j.objects.LabelWrapper _mlabel = null;
public anywheresoftware.b4j.objects.LabelWrapper _miconlabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xlabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xiconlabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _xparent = null;
public anywheresoftware.b4a.objects.B4XCanvas _cvsbase = null;
public anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rectbase = null;
public int _mpressedcolor = 0;
public int _mbackgroundcolor = 0;
public int _monstatecolor = 0;
public int _monstatebackgroundcolor = 0;
public boolean _monstate = false;
public String _mbuttontype = "";
public String _monstatetext = "";
public anywheresoftware.b4a.objects.Timer _tmrclick = null;
public long _mtimedown = 0L;
public long _mclicktime = 0L;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(Object _parent,int _left,int _top,int _width,int _height,Object _textcolor,String _icon,String _text) throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Public Sub AddToParent(Parent As Object, Left As I";
 //BA.debugLineNum = 116;BA.debugLine="mLeft = Left";
_mleft = _left;
 //BA.debugLineNum = 117;BA.debugLine="mTop = Top";
_mtop = _top;
 //BA.debugLineNum = 118;BA.debugLine="mWidth = Width";
_mwidth = _width;
 //BA.debugLineNum = 119;BA.debugLine="mHeight = Height";
_mheight = _height;
 //BA.debugLineNum = 120;BA.debugLine="xParent = Parent";
_xparent = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_parent));
 //BA.debugLineNum = 122;BA.debugLine="xBase = xui.CreatePanel(\"xBase\")";
_xbase = _xui.CreatePanel(ba,"xBase");
 //BA.debugLineNum = 124;BA.debugLine="xParent.AddView(xBase, mLeft, mTop, mWidth, mHeig";
_xparent.AddView((javafx.scene.Node)(_xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 126;BA.debugLine="mIcon = Icon";
_micon = _icon;
 //BA.debugLineNum = 127;BA.debugLine="mText = Text";
_mtext = _text;
 //BA.debugLineNum = 128;BA.debugLine="mTextColor = xui.PaintOrColorToColor(TextColor)";
_mtextcolor = _xui.PaintOrColorToColor(_textcolor);
 //BA.debugLineNum = 130;BA.debugLine="xIconFont = xui.CreateMaterialIcons(10)";
_xiconfont = _xui.CreateMaterialIcons((float) (10));
 //BA.debugLineNum = 132;BA.debugLine="InitClass";
_initclass();
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 27;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 29;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 31;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 32;BA.debugLine="Private mCallBack As Object";
_mcallback = new Object();
 //BA.debugLineNum = 33;BA.debugLine="Private xBase As B4XView";
_xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 36;BA.debugLine="Private mText, mIcon As String";
_mtext = "";
_micon = "";
 //BA.debugLineNum = 38;BA.debugLine="Private xLabelFont, xIconFont As B4XFont";
_xlabelfont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
_xiconfont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
 //BA.debugLineNum = 40;BA.debugLine="Private mTextColor As Int";
_mtextcolor = 0;
 //BA.debugLineNum = 41;BA.debugLine="Private mIconTextSize, mLabelTextSize As Double";
_micontextsize = 0;
_mlabeltextsize = 0;
 //BA.debugLineNum = 42;BA.debugLine="Private mTag As Object";
_mtag = new Object();
 //BA.debugLineNum = 44;BA.debugLine="Private mLabel, mIconLabel As Label";
_mlabel = new anywheresoftware.b4j.objects.LabelWrapper();
_miconlabel = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private xLabel, xIconLabel As B4XView";
_xlabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
_xiconlabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private xParent As B4XView";
_xparent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private cvsBase As B4XCanvas";
_cvsbase = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 48;BA.debugLine="Private rectBase As B4XRect";
_rectbase = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 49;BA.debugLine="Private mPressedColor, mBackgroundColor, mOnState";
_mpressedcolor = 0;
_mbackgroundcolor = 0;
_monstatecolor = 0;
_monstatebackgroundcolor = 0;
 //BA.debugLineNum = 50;BA.debugLine="Private mONState = False As Boolean";
_monstate = __c.False;
 //BA.debugLineNum = 51;BA.debugLine="Private mButtonType As String";
_mbuttontype = "";
 //BA.debugLineNum = 52;BA.debugLine="Private mOnStateText As String";
_monstatetext = "";
 //BA.debugLineNum = 54;BA.debugLine="Private tmrClick As Timer";
_tmrclick = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 55;BA.debugLine="Private mTimeDown, mClickTime As Long	'used to di";
_mtimedown = 0L;
_mclicktime = 0L;
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _mdummy = null;
 //BA.debugLineNum = 76;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 77;BA.debugLine="Private mDummy As B4XView";
_mdummy = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 78;BA.debugLine="mDummy = Base";
_mdummy = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 79;BA.debugLine="mLeft = mDummy.Left";
_mleft = (int) (_mdummy.getLeft());
 //BA.debugLineNum = 80;BA.debugLine="mTop = mDummy.Top";
_mtop = (int) (_mdummy.getTop());
 //BA.debugLineNum = 81;BA.debugLine="mWidth = mDummy.Width";
_mwidth = (int) (_mdummy.getWidth());
 //BA.debugLineNum = 82;BA.debugLine="mHeight = mDummy.Height";
_mheight = (int) (_mdummy.getHeight());
 //BA.debugLineNum = 83;BA.debugLine="mIcon = Lbl.Text";
_micon = _lbl.getText();
 //BA.debugLineNum = 84;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 85;BA.debugLine="mPressedColor = xui.PaintOrColorToColor(Props.Get";
_mpressedcolor = _xui.PaintOrColorToColor(_props.Get((Object)("PressedColor")));
 //BA.debugLineNum = 86;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props.";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 87;BA.debugLine="If mBackgroundColor = 16777215 Then";
if (_mbackgroundcolor==16777215) { 
 //BA.debugLineNum = 88;BA.debugLine="mBackgroundColor = xui.Color_Transparent";
_mbackgroundcolor = _xui.Color_Transparent;
 };
 //BA.debugLineNum = 90;BA.debugLine="mButtonType = Props.Get(\"ButtonType\")";
_mbuttontype = BA.ObjectToString(_props.Get((Object)("ButtonType")));
 //BA.debugLineNum = 91;BA.debugLine="mOnStateText = Props.Get(\"OnStateText\")";
_monstatetext = BA.ObjectToString(_props.Get((Object)("OnStateText")));
 //BA.debugLineNum = 92;BA.debugLine="mOnStateColor = xui.PaintOrColorToColor(Props.Get";
_monstatecolor = _xui.PaintOrColorToColor(_props.Get((Object)("OnStateColor")));
 //BA.debugLineNum = 93;BA.debugLine="mOnStateBackgroundColor = xui.PaintOrColorToColor";
_monstatebackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("OnStateBackgroundColor")));
 //BA.debugLineNum = 95;BA.debugLine="xBase = xui.CreatePanel(\"xBase\")";
_xbase = _xui.CreatePanel(ba,"xBase");
 //BA.debugLineNum = 96;BA.debugLine="xParent = mDummy.Parent";
_xparent = _mdummy.getParent();
 //BA.debugLineNum = 97;BA.debugLine="xParent.AddView(xBase, mLeft, mTop, mWidth, mHeig";
_xparent.AddView((javafx.scene.Node)(_xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 98;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Lbl.TextColo";
_mtextcolor = _xui.PaintOrColorToColor((Object)(_lbl.getTextColor()));
 //BA.debugLineNum = 99;BA.debugLine="mTag = mDummy.Tag";
_mtag = _mdummy.getTag();
 //BA.debugLineNum = 105;BA.debugLine="xIconFont = Lbl.Font";
_xiconfont = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont(), (javafx.scene.text.Font)(_lbl.getFont().getObject()));
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public Object  _getbase() throws Exception{
 //BA.debugLineNum = 111;BA.debugLine="Public Sub GetBase As Object";
 //BA.debugLineNum = 112;BA.debugLine="Return xBase";
if (true) return (Object)(_xbase.getObject());
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return null;
}
public String  _geticon() throws Exception{
 //BA.debugLineNum = 255;BA.debugLine="Public Sub getIcon As String";
 //BA.debugLineNum = 256;BA.debugLine="Return xIconLabel.Text";
if (true) return _xiconlabel.getText();
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
return "";
}
public int  _getpressedcolor() throws Exception{
 //BA.debugLineNum = 264;BA.debugLine="Public Sub getPressedColor As Int";
 //BA.debugLineNum = 265;BA.debugLine="Return mPressedColor";
if (true) return _mpressedcolor;
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return 0;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 246;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 247;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 248;BA.debugLine="End Sub";
return null;
}
public String  _initclass() throws Exception{
int _lblleft = 0;
int _lblwidth = 0;
 //BA.debugLineNum = 135;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 137;BA.debugLine="Private lblLeft, lblWidth  As Int";
_lblleft = 0;
_lblwidth = 0;
 //BA.debugLineNum = 138;BA.debugLine="lblWidth = 2 * mHeight / 3		'icon Label width and";
_lblwidth = (int) (2*_mheight/(double)3);
 //BA.debugLineNum = 139;BA.debugLine="lblLeft = (mWidth - lblWidth) / 2";
_lblleft = (int) ((_mwidth-_lblwidth)/(double)2);
 //BA.debugLineNum = 142;BA.debugLine="mIconLabel.Initialize(\"\")";
_miconlabel.Initialize(ba,"");
 //BA.debugLineNum = 143;BA.debugLine="xIconLabel = mIconLabel";
_xiconlabel = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_miconlabel.getObject()));
 //BA.debugLineNum = 145;BA.debugLine="mIconTextSize = mHeight / 2 / xui.Scale";
_micontextsize = _mheight/(double)2/(double)_xui.getScale();
 //BA.debugLineNum = 146;BA.debugLine="mLabelTextSize = lblWidth / 3 / xui.Scale";
_mlabeltextsize = _lblwidth/(double)3/(double)_xui.getScale();
 //BA.debugLineNum = 147;BA.debugLine="xLabelFont = xui.CreateDefaultFont(10)";
_xlabelfont = _xui.CreateDefaultFont((float) (10));
 //BA.debugLineNum = 149;BA.debugLine="xIconLabel.Font = xIconFont";
_xiconlabel.setFont(_xiconfont);
 //BA.debugLineNum = 150;BA.debugLine="xIconLabel.SetTextAlignment(\"CENTER\", \"CENTER\")";
_xiconlabel.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 151;BA.debugLine="xIconLabel.TextSize = mIconTextSize";
_xiconlabel.setTextSize(_micontextsize);
 //BA.debugLineNum = 152;BA.debugLine="xIconLabel.TextColor = xui.PaintOrColorToColor(mT";
_xiconlabel.setTextColor(_xui.PaintOrColorToColor((Object)(_mtextcolor)));
 //BA.debugLineNum = 153;BA.debugLine="xBase.AddView(xIconLabel, lblLeft, 0, lblWidth, l";
_xbase.AddView((javafx.scene.Node)(_xiconlabel.getObject()),_lblleft,0,_lblwidth,_lblwidth);
 //BA.debugLineNum = 154;BA.debugLine="xIconLabel.Text = mIcon";
_xiconlabel.setText(_micon);
 //BA.debugLineNum = 157;BA.debugLine="mLabel.Initialize(\"\")";
_mlabel.Initialize(ba,"");
 //BA.debugLineNum = 158;BA.debugLine="xLabel = mLabel";
_xlabel = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mlabel.getObject()));
 //BA.debugLineNum = 159;BA.debugLine="xLabel.SetTextAlignment(\"TOP\", \"CENTER\")";
_xlabel.SetTextAlignment("TOP","CENTER");
 //BA.debugLineNum = 160;BA.debugLine="xLabel.Font = xLabelFont";
_xlabel.setFont(_xlabelfont);
 //BA.debugLineNum = 161;BA.debugLine="xLabel.TextSize = mLabelTextSize";
_xlabel.setTextSize(_mlabeltextsize);
 //BA.debugLineNum = 162;BA.debugLine="xLabel.TextColor = xui.PaintOrColorToColor(mTextC";
_xlabel.setTextColor(_xui.PaintOrColorToColor((Object)(_mtextcolor)));
 //BA.debugLineNum = 163;BA.debugLine="xBase.AddView(xLabel, 0, 2 * mHeight / 3, mWidth,";
_xbase.AddView((javafx.scene.Node)(_xlabel.getObject()),0,2*_mheight/(double)3,_mwidth,_mheight/(double)3);
 //BA.debugLineNum = 164;BA.debugLine="xLabel.Text = mText";
_xlabel.setText(_mtext);
 //BA.debugLineNum = 166;BA.debugLine="cvsBase.Initialize(xBase)";
_cvsbase.Initialize(ba,_xbase);
 //BA.debugLineNum = 167;BA.debugLine="rectBase.Initialize(0, 0, xBase.Width, xBase.Heig";
_rectbase.Initialize((float) (0),(float) (0),(float) (_xbase.getWidth()),(float) (_xbase.getHeight()));
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 58;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 59;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 60;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 62;BA.debugLine="mIcon = Chr(0xE859)";
_micon = BA.ObjectToString(__c.Chr(((int)0xe859)));
 //BA.debugLineNum = 63;BA.debugLine="mText = \"Test\"";
_mtext = "Test";
 //BA.debugLineNum = 64;BA.debugLine="mTextColor = xui.Color_Black";
_mtextcolor = _xui.Color_Black;
 //BA.debugLineNum = 66;BA.debugLine="mClickTime = 400";
_mclicktime = (long) (400);
 //BA.debugLineNum = 67;BA.debugLine="tmrClick.Initialize(\"tmrClick\", mClickTime)";
_tmrclick.Initialize(ba,"tmrClick",_mclicktime);
 //BA.debugLineNum = 69;BA.debugLine="mPressedColor = xui.Color_Yellow";
_mpressedcolor = _xui.Color_Yellow;
 //BA.debugLineNum = 70;BA.debugLine="mButtonType = \"STANDARD\"";
_mbuttontype = "STANDARD";
 //BA.debugLineNum = 71;BA.debugLine="mBackgroundColor = xui.Color_Transparent";
_mbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 72;BA.debugLine="mOnStateColor = xui.Color_Blue";
_monstatecolor = _xui.Color_Blue;
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public String  _seticon(String _icon) throws Exception{
 //BA.debugLineNum = 251;BA.debugLine="Public Sub setIcon(Icon As String)";
 //BA.debugLineNum = 252;BA.debugLine="xIconLabel.Text = Icon";
_xiconlabel.setText(_icon);
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return "";
}
public String  _seticonfont(anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _iconfont) throws Exception{
 //BA.debugLineNum = 234;BA.debugLine="Public Sub setIconFont(IconFont As B4XFont)";
 //BA.debugLineNum = 235;BA.debugLine="xIconFont = IconFont";
_xiconfont = _iconfont;
 //BA.debugLineNum = 236;BA.debugLine="xIconLabel.Font = xIconFont";
_xiconlabel.setFont(_xiconfont);
 //BA.debugLineNum = 237;BA.debugLine="xIconLabel.TextSize = mIconTextSize";
_xiconlabel.setTextSize(_micontextsize);
 //BA.debugLineNum = 238;BA.debugLine="End Sub";
return "";
}
public String  _setlabelfont(anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _labelfont) throws Exception{
 //BA.debugLineNum = 226;BA.debugLine="Public Sub setLabelFont(LabelFont As B4XFont)";
 //BA.debugLineNum = 227;BA.debugLine="xLabelFont = LabelFont";
_xlabelfont = _labelfont;
 //BA.debugLineNum = 228;BA.debugLine="xLabel.Font = xLabelFont";
_xlabel.setFont(_xlabelfont);
 //BA.debugLineNum = 229;BA.debugLine="xLabel.TextSize = mLabelTextSize";
_xlabel.setTextSize(_mlabeltextsize);
 //BA.debugLineNum = 230;BA.debugLine="End Sub";
return "";
}
public String  _setpressedcolor(int _pressedcolor) throws Exception{
 //BA.debugLineNum = 260;BA.debugLine="Public Sub setPressedColor(PressedColor As Int)";
 //BA.debugLineNum = 261;BA.debugLine="mPressedColor = PressedColor";
_mpressedcolor = _pressedcolor;
 //BA.debugLineNum = 262;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 241;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 242;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 243;BA.debugLine="xBase.Tag = Tag";
_xbase.setTag(_tag);
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _tmrclick_tick() throws Exception{
 //BA.debugLineNum = 218;BA.debugLine="Private Sub tmrClick_Tick";
 //BA.debugLineNum = 219;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_LongCl";
if (_xui.SubExists(ba,_mcallback,_meventname+"_LongClick",(int) (0))) { 
 //BA.debugLineNum = 220;BA.debugLine="CallSubDelayed(mCallBack, mEventName & \"_LongCli";
__c.CallSubDelayed(ba,_mcallback,_meventname+"_LongClick");
 //BA.debugLineNum = 221;BA.debugLine="tmrClick.Enabled = False";
_tmrclick.setEnabled(__c.False);
 };
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return "";
}
public String  _xbase_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 170;BA.debugLine="Private Sub xBase_Touch(Action As Int, X As Float,";
 //BA.debugLineNum = 171;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_xbase.TOUCH_ACTION_DOWN,_xbase.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 173;BA.debugLine="mTimeDown = DateTime.Now";
_mtimedown = __c.DateTime.getNow();
 //BA.debugLineNum = 174;BA.debugLine="tmrClick.Enabled = True";
_tmrclick.setEnabled(__c.True);
 //BA.debugLineNum = 175;BA.debugLine="Select mButtonType";
switch (BA.switchObjectToInt(_mbuttontype,"STANDARD","TOGGLE")) {
case 0: {
 //BA.debugLineNum = 177;BA.debugLine="xBase.Color = mPressedColor";
_xbase.setColor(_mpressedcolor);
 break; }
case 1: {
 //BA.debugLineNum = 179;BA.debugLine="If mONState = False Then";
if (_monstate==__c.False) { 
 //BA.debugLineNum = 180;BA.debugLine="xBase.Color = mOnStateBackgroundColor";
_xbase.setColor(_monstatebackgroundcolor);
 //BA.debugLineNum = 181;BA.debugLine="mONState = True";
_monstate = __c.True;
 //BA.debugLineNum = 182;BA.debugLine="xLabel.Text = mOnStateText";
_xlabel.setText(_monstatetext);
 //BA.debugLineNum = 183;BA.debugLine="xLabel.TextColor = mOnStateColor";
_xlabel.setTextColor(_monstatecolor);
 //BA.debugLineNum = 185;BA.debugLine="xIconLabel.TextColor = mOnStateColor";
_xiconlabel.setTextColor(_monstatecolor);
 }else {
 //BA.debugLineNum = 187;BA.debugLine="If mBackgroundColor = xui.Color_Transparent";
if (_mbackgroundcolor==_xui.Color_Transparent) { 
 //BA.debugLineNum = 188;BA.debugLine="cvsBase.ClearRect(rectBase)";
_cvsbase.ClearRect(_rectbase);
 //BA.debugLineNum = 189;BA.debugLine="cvsBase.Invalidate";
_cvsbase.Invalidate();
 }else {
 //BA.debugLineNum = 191;BA.debugLine="xBase.Color = mBackgroundColor";
_xbase.setColor(_mbackgroundcolor);
 };
 //BA.debugLineNum = 193;BA.debugLine="mONState = False";
_monstate = __c.False;
 //BA.debugLineNum = 194;BA.debugLine="xLabel.Text = mText";
_xlabel.setText(_mtext);
 //BA.debugLineNum = 195;BA.debugLine="xLabel.TextColor = mTextColor";
_xlabel.setTextColor(_mtextcolor);
 //BA.debugLineNum = 196;BA.debugLine="xIconLabel.TextColor = mTextColor";
_xiconlabel.setTextColor(_mtextcolor);
 };
 break; }
}
;
 break; }
case 1: {
 //BA.debugLineNum = 200;BA.debugLine="Select mButtonType";
switch (BA.switchObjectToInt(_mbuttontype,"STANDARD","TOGGLE")) {
case 0: {
 //BA.debugLineNum = 202;BA.debugLine="If DateTime.Now - mTimeDown <= mClickTime The";
if (__c.DateTime.getNow()-_mtimedown<=_mclicktime) { 
 //BA.debugLineNum = 203;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_C";
if (_xui.SubExists(ba,_mcallback,_meventname+"_Click",(int) (0))) { 
 //BA.debugLineNum = 204;BA.debugLine="CallSubDelayed(mCallBack, mEventName & \"_Cl";
__c.CallSubDelayed(ba,_mcallback,_meventname+"_Click");
 //BA.debugLineNum = 205;BA.debugLine="tmrClick.Enabled = False";
_tmrclick.setEnabled(__c.False);
 };
 };
 //BA.debugLineNum = 208;BA.debugLine="xBase.Color = mBackgroundColor";
_xbase.setColor(_mbackgroundcolor);
 break; }
case 1: {
 //BA.debugLineNum = 210;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Ch";
if (_xui.SubExists(ba,_mcallback,_meventname+"_CheckedChange",(int) (1))) { 
 //BA.debugLineNum = 211;BA.debugLine="CallSubDelayed2(mCallBack, mEventName & \"_Ch";
__c.CallSubDelayed2(ba,_mcallback,_meventname+"_CheckedChange",(Object)(_monstate));
 //BA.debugLineNum = 212;BA.debugLine="tmrClick.Enabled = False";
_tmrclick.setEnabled(__c.False);
 };
 break; }
}
;
 break; }
}
;
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
