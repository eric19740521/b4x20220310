package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _pane1 = null;
public static b4j.example.xyzbutton _xyzbutton1 = null;
public static b4j.example.xyzbutton _xyzbutton7 = null;
public static b4j.example.xyzlabel _xyzlabel1 = null;
public static b4j.example.xyzlabel _xyzlabel7 = null;
public static b4j.example.xyzbuttonn _xyzbuttonn1 = null;
public static b4j.example.xyzbuttonn _xyzbuttonn7 = null;
public static b4j.example.bctoast _toast = null;
public static b4j.example.jxyzbuttonn _jxyzbuttonn7 = null;
public static b4j.example.jxyzbuttonn _jxyzbuttonn1 = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.b4xcollections _b4xcollections = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
anywheresoftware.b4a.objects.collections.Map _props = null;
anywheresoftware.b4a.objects.collections.Map _props2 = null;
anywheresoftware.b4a.objects.collections.Map _props3 = null;
anywheresoftware.b4a.objects.collections.Map _props7 = null;
 //BA.debugLineNum = 31;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 32;BA.debugLine="Log(\"AppStart=================>Loyout\")";
anywheresoftware.b4a.keywords.Common.LogImpl("665537","AppStart=================>Loyout",0);
 //BA.debugLineNum = 34;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 35;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 37;BA.debugLine="Log(\"AppStart=================>Show A1\")";
anywheresoftware.b4a.keywords.Common.LogImpl("665542","AppStart=================>Show A1",0);
 //BA.debugLineNum = 38;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 39;BA.debugLine="Log(\"AppStart=================>Show A2\")";
anywheresoftware.b4a.keywords.Common.LogImpl("665544","AppStart=================>Show A2",0);
 //BA.debugLineNum = 41;BA.debugLine="toast.Initialize(MainForm.RootPane)";
_toast._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mainform.getRootPane().getObject())));
 //BA.debugLineNum = 45;BA.debugLine="Dim props As Map";
_props = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 47;BA.debugLine="props.Initialize";
_props.Initialize();
 //BA.debugLineNum = 49;BA.debugLine="props.Put(\"Left\" , 300 )";
_props.Put((Object)("Left"),(Object)(300));
 //BA.debugLineNum = 50;BA.debugLine="props.Put(\"Top\" , 20 )";
_props.Put((Object)("Top"),(Object)(20));
 //BA.debugLineNum = 51;BA.debugLine="props.Put(\"Width\" , 200 )";
_props.Put((Object)("Width"),(Object)(200));
 //BA.debugLineNum = 52;BA.debugLine="props.Put(\"Height\" , 100 )";
_props.Put((Object)("Height"),(Object)(100));
 //BA.debugLineNum = 54;BA.debugLine="props.Put(\"Text\" , \"標籤7\" )";
_props.Put((Object)("Text"),(Object)("標籤7"));
 //BA.debugLineNum = 55;BA.debugLine="props.Put(\"TextColor\" , xui.Color_Black )";
_props.Put((Object)("TextColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 56;BA.debugLine="props.Put(\"Tag\" , \"\" )";
_props.Put((Object)("Tag"),(Object)(""));
 //BA.debugLineNum = 57;BA.debugLine="props.Put(\"BorderWidth\" , 1dip )";
_props.Put((Object)("BorderWidth"),(Object)(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 58;BA.debugLine="props.Put(\"BorderColor\" , xui.Color_Black )";
_props.Put((Object)("BorderColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 59;BA.debugLine="props.Put(\"PressedColor\" , xui.Color_Yellow  )		'";
_props.Put((Object)("PressedColor"),(Object)(_xui.Color_Yellow));
 //BA.debugLineNum = 60;BA.debugLine="props.Put(\"BackgroundColor\" , xui.Color_RGB(218,2";
_props.Put((Object)("BackgroundColor"),(Object)(_xui.Color_RGB((int) (218),(int) (218),(int) (218))));
 //BA.debugLineNum = 62;BA.debugLine="xyzLabel7.Initialize(Me,\"xyzLabel7\")";
_xyzlabel7._initialize /*String*/ (ba,main.getObject(),"xyzLabel7");
 //BA.debugLineNum = 63;BA.debugLine="xyzLabel7.AddToParent(Pane1 , props )";
_xyzlabel7._addtoparent /*String*/ ((Object)(_pane1.getObject()),_props);
 //BA.debugLineNum = 64;BA.debugLine="xyzLabel7.TextSize = 16";
_xyzlabel7._settextsize /*int*/ ((int) (16));
 //BA.debugLineNum = 65;BA.debugLine="xyzLabel7.SetTextAlignment(\"CENTER\",\"RIGHT\")";
_xyzlabel7._settextalignment /*String*/ ("CENTER","RIGHT");
 //BA.debugLineNum = 71;BA.debugLine="Dim props2 As Map";
_props2 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 73;BA.debugLine="props2.Initialize";
_props2.Initialize();
 //BA.debugLineNum = 75;BA.debugLine="props2.Put(\"Left\" , 300 )";
_props2.Put((Object)("Left"),(Object)(300));
 //BA.debugLineNum = 76;BA.debugLine="props2.Put(\"Top\" , 130 )";
_props2.Put((Object)("Top"),(Object)(130));
 //BA.debugLineNum = 77;BA.debugLine="props2.Put(\"Width\" , 100 )";
_props2.Put((Object)("Width"),(Object)(100));
 //BA.debugLineNum = 78;BA.debugLine="props2.Put(\"Height\" , 100 )";
_props2.Put((Object)("Height"),(Object)(100));
 //BA.debugLineNum = 80;BA.debugLine="props2.Put(\"Text\" , \"按鈕7\" )";
_props2.Put((Object)("Text"),(Object)("按鈕7"));
 //BA.debugLineNum = 81;BA.debugLine="props2.Put(\"TextColor\" , xui.Color_Black )";
_props2.Put((Object)("TextColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 82;BA.debugLine="props2.Put(\"Tag\" , \"\" )";
_props2.Put((Object)("Tag"),(Object)(""));
 //BA.debugLineNum = 83;BA.debugLine="props2.Put(\"BorderWidth\" , 1dip )";
_props2.Put((Object)("BorderWidth"),(Object)(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 84;BA.debugLine="props2.Put(\"BorderColor\" , xui.Color_Black )";
_props2.Put((Object)("BorderColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 85;BA.debugLine="props2.Put(\"PressedColor\" , xui.Color_Yellow  )";
_props2.Put((Object)("PressedColor"),(Object)(_xui.Color_Yellow));
 //BA.debugLineNum = 86;BA.debugLine="props2.Put(\"BackgroundColor\" , xui.Color_RGB(218,";
_props2.Put((Object)("BackgroundColor"),(Object)(_xui.Color_RGB((int) (218),(int) (218),(int) (218))));
 //BA.debugLineNum = 88;BA.debugLine="xyzButton7.Initialize(Me,\"xyzButton7\")";
_xyzbutton7._initialize /*String*/ (ba,main.getObject(),"xyzButton7");
 //BA.debugLineNum = 89;BA.debugLine="xyzButton7.AddToParent(Pane1, props2 )";
_xyzbutton7._addtoparent /*String*/ ((Object)(_pane1.getObject()),_props2);
 //BA.debugLineNum = 95;BA.debugLine="Dim props3 As Map";
_props3 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 97;BA.debugLine="props3.Initialize";
_props3.Initialize();
 //BA.debugLineNum = 99;BA.debugLine="props3.Put(\"Left\" , 300 )";
_props3.Put((Object)("Left"),(Object)(300));
 //BA.debugLineNum = 100;BA.debugLine="props3.Put(\"Top\" , 250 )";
_props3.Put((Object)("Top"),(Object)(250));
 //BA.debugLineNum = 101;BA.debugLine="props3.Put(\"Width\" , 100 )";
_props3.Put((Object)("Width"),(Object)(100));
 //BA.debugLineNum = 102;BA.debugLine="props3.Put(\"Height\" , 100 )";
_props3.Put((Object)("Height"),(Object)(100));
 //BA.debugLineNum = 104;BA.debugLine="props3.Put(\"Text\" , \"按鈕N7\" )";
_props3.Put((Object)("Text"),(Object)("按鈕N7"));
 //BA.debugLineNum = 105;BA.debugLine="props3.Put(\"TextColor\" , xui.Color_Black )";
_props3.Put((Object)("TextColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 106;BA.debugLine="props3.Put(\"Tag\" , \"tag\" )";
_props3.Put((Object)("Tag"),(Object)("tag"));
 //BA.debugLineNum = 107;BA.debugLine="props3.Put(\"BorderWidth\" , 1dip )";
_props3.Put((Object)("BorderWidth"),(Object)(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 108;BA.debugLine="props3.Put(\"BorderColor\" , xui.Color_Black )";
_props3.Put((Object)("BorderColor"),(Object)(_xui.Color_Black));
 //BA.debugLineNum = 109;BA.debugLine="props3.Put(\"PressedColor\" , xui.Color_Red  )";
_props3.Put((Object)("PressedColor"),(Object)(_xui.Color_Red));
 //BA.debugLineNum = 110;BA.debugLine="props3.Put(\"BackgroundColor\" , xui.Color_ARGB(255";
_props3.Put((Object)("BackgroundColor"),(Object)(_xui.Color_ARGB((int) (255),(int) (148),(int) (241),(int) (144))));
 //BA.debugLineNum = 112;BA.debugLine="xyzButtonN7.Initialize(Me,\"xyzButtonN7\")";
_xyzbuttonn7._initialize /*String*/ (ba,main.getObject(),"xyzButtonN7");
 //BA.debugLineNum = 113;BA.debugLine="xyzButtonN7.AddToParent(Pane1, props3 )";
_xyzbuttonn7._addtoparent /*String*/ ((Object)(_pane1.getObject()),_props3);
 //BA.debugLineNum = 115;BA.debugLine="xyzButtonN7.BackgroundColor = xui.Color_Blue";
_xyzbuttonn7._setbackgroundcolor /*int*/ (_xui.Color_Blue);
 //BA.debugLineNum = 116;BA.debugLine="xyzButtonN7.TextColor = xui.Color_White";
_xyzbuttonn7._settextcolor(_xui.Color_White);
 //BA.debugLineNum = 117;BA.debugLine="xyzButtonN7.SetTextAlignment(\"CENTER\", \"CENTER\")";
_xyzbuttonn7._settextalignment /*String*/ ("CENTER","CENTER");
 //BA.debugLineNum = 123;BA.debugLine="Dim props7 As Map";
_props7 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 125;BA.debugLine="props7.Initialize";
_props7.Initialize();
 //BA.debugLineNum = 127;BA.debugLine="props7.Put(\"Left\" , 300 )";
_props7.Put((Object)("Left"),(Object)(300));
 //BA.debugLineNum = 128;BA.debugLine="props7.Put(\"Top\" , 400 )";
_props7.Put((Object)("Top"),(Object)(400));
 //BA.debugLineNum = 129;BA.debugLine="props7.Put(\"Width\" , 100 )";
_props7.Put((Object)("Width"),(Object)(100));
 //BA.debugLineNum = 130;BA.debugLine="props7.Put(\"Height\" , 100 )";
_props7.Put((Object)("Height"),(Object)(100));
 //BA.debugLineNum = 132;BA.debugLine="props7.Put(\"Text\" , \"ABC\" )";
_props7.Put((Object)("Text"),(Object)("ABC"));
 //BA.debugLineNum = 133;BA.debugLine="props7.Put(\"TextColor\" , fx.Colors.Black )";
_props7.Put((Object)("TextColor"),(Object)(_fx.Colors.Black));
 //BA.debugLineNum = 134;BA.debugLine="props7.Put(\"TextAlignment\" , \"CENTER\" )";
_props7.Put((Object)("TextAlignment"),(Object)("CENTER"));
 //BA.debugLineNum = 135;BA.debugLine="props7.Put(\"Tag\" , \"tag\" )";
_props7.Put((Object)("Tag"),(Object)("tag"));
 //BA.debugLineNum = 136;BA.debugLine="props7.Put(\"BorderWidth\" , 1 )";
_props7.Put((Object)("BorderWidth"),(Object)(1));
 //BA.debugLineNum = 137;BA.debugLine="props7.Put(\"BorderColor\" , fx.Colors.Black )";
_props7.Put((Object)("BorderColor"),(Object)(_fx.Colors.Black));
 //BA.debugLineNum = 138;BA.debugLine="props7.Put(\"PressedColor\" , fx.Colors.Red  )";
_props7.Put((Object)("PressedColor"),(Object)(_fx.Colors.Red));
 //BA.debugLineNum = 139;BA.debugLine="props7.Put(\"BackgroundColor\" , fx.Colors.ARGB(255";
_props7.Put((Object)("BackgroundColor"),(Object)(_fx.Colors.ARGB((int) (255),(int) (148),(int) (241),(int) (144))));
 //BA.debugLineNum = 143;BA.debugLine="jxyzButtonN7.Initialize(Me,\"jxyzButtonN7\")";
_jxyzbuttonn7._initialize /*String*/ (ba,main.getObject(),"jxyzButtonN7");
 //BA.debugLineNum = 144;BA.debugLine="jxyzButtonN7.AddToParent(Pane1 , props7 )";
_jxyzbuttonn7._addtoparent /*String*/ ((anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_pane1.getObject())),_props7);
 //BA.debugLineNum = 151;BA.debugLine="Log(\"AppStart=================>end\")";
anywheresoftware.b4a.keywords.Common.LogImpl("665656","AppStart=================>end",0);
 //BA.debugLineNum = 204;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
anywheresoftware.b4j.objects.ButtonWrapper _xbutton = null;
 //BA.debugLineNum = 211;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 213;BA.debugLine="Dim xButton As Button";
_xbutton = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 215;BA.debugLine="xButton = Sender";
_xbutton = (anywheresoftware.b4j.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.ButtonWrapper(), (javafx.scene.control.Button)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 216;BA.debugLine="Log(\"tag= \"&xButton.tag )";
anywheresoftware.b4a.keywords.Common.LogImpl("615859717","tag= "+BA.ObjectToString(_xbutton.getTag()),0);
 //BA.debugLineNum = 219;BA.debugLine="xui.MsgboxAsync(\"Hello World!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!","B4X");
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public static String  _form_resize() throws Exception{
 //BA.debugLineNum = 206;BA.debugLine="Sub Form_Resize";
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return "";
}
public static String  _jxyzbuttonn1_click() throws Exception{
 //BA.debugLineNum = 267;BA.debugLine="Private Sub jxyzButtonN1_Click";
 //BA.debugLineNum = 268;BA.debugLine="toast.pnl.Color = xui.Color_ARGB(255,93,213,241)";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_xui.Color_ARGB((int) (255),(int) (93),(int) (213),(int) (241)));
 //BA.debugLineNum = 269;BA.debugLine="toast.Show($\"B4X [b]jxyzButton1 [/b] \"$ & jxyzBut";
_toast._show /*void*/ (("B4X [b]jxyzButton1 [/b] ")+_jxyzbuttonn1._gettextalignment /*String*/ ());
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return "";
}
public static String  _jxyzbuttonn7_click() throws Exception{
 //BA.debugLineNum = 258;BA.debugLine="Private Sub jxyzButtonN7_Click";
 //BA.debugLineNum = 259;BA.debugLine="toast.pnl.Color = xui.Color_ARGB(255,148,241,144)";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_xui.Color_ARGB((int) (255),(int) (148),(int) (241),(int) (144)));
 //BA.debugLineNum = 260;BA.debugLine="toast.Show($\"B4X [b]jxyzButton7 [/b] \"$ & jxyzBut";
_toast._show /*void*/ (("B4X [b]jxyzButton7 [/b] ")+_jxyzbuttonn7._gettextalignment /*String*/ ());
 //BA.debugLineNum = 265;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.cssutils._process_globals();
main._process_globals();
httputils2service._process_globals();
b4xcollections._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private Pane1 As B4XView";
_pane1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private xyzButton1 As xyzButton";
_xyzbutton1 = new b4j.example.xyzbutton();
 //BA.debugLineNum = 14;BA.debugLine="Private xyzButton7 As xyzButton";
_xyzbutton7 = new b4j.example.xyzbutton();
 //BA.debugLineNum = 15;BA.debugLine="Private xyzLabel1 As xyzLabel";
_xyzlabel1 = new b4j.example.xyzlabel();
 //BA.debugLineNum = 16;BA.debugLine="Private xyzLabel7 As xyzLabel";
_xyzlabel7 = new b4j.example.xyzlabel();
 //BA.debugLineNum = 17;BA.debugLine="Private xyzButtonN1 As xyzButtonN";
_xyzbuttonn1 = new b4j.example.xyzbuttonn();
 //BA.debugLineNum = 18;BA.debugLine="Private xyzButtonN7 As xyzButtonN";
_xyzbuttonn7 = new b4j.example.xyzbuttonn();
 //BA.debugLineNum = 22;BA.debugLine="Dim toast As BCToast";
_toast = new b4j.example.bctoast();
 //BA.debugLineNum = 27;BA.debugLine="Dim jxyzButtonN7 As jxyzButtonN";
_jxyzbuttonn7 = new b4j.example.jxyzbuttonn();
 //BA.debugLineNum = 28;BA.debugLine="Private jxyzButtonN1 As jxyzButtonN";
_jxyzbuttonn1 = new b4j.example.jxyzbuttonn();
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public static String  _xyzbutton1_click() throws Exception{
 //BA.debugLineNum = 224;BA.debugLine="Private Sub xyzButton1_Click";
 //BA.debugLineNum = 227;BA.debugLine="toast.pnl.Color = xui.Color_ARGB(255,255,0,255)";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_xui.Color_ARGB((int) (255),(int) (255),(int) (0),(int) (255)));
 //BA.debugLineNum = 228;BA.debugLine="toast.Show($\"B4X [b]xyzButton1_Click[/b] \"$ & xyz";
_toast._show /*void*/ (("B4X [b]xyzButton1_Click[/b] ")+BA.NumberToString(_xyzbutton1._gettop /*int*/ ()));
 //BA.debugLineNum = 229;BA.debugLine="End Sub";
return "";
}
public static String  _xyzbutton7_click() throws Exception{
 //BA.debugLineNum = 231;BA.debugLine="Private Sub xyzButton7_Click";
 //BA.debugLineNum = 236;BA.debugLine="toast.Show($\"B4X [b]xyzButtonN7 [/b] \"$ & xyzButt";
_toast._show /*void*/ (("B4X [b]xyzButtonN7 [/b] ")+BA.ObjectToString(_xyzbutton7._gettag /*Object*/ ()));
 //BA.debugLineNum = 238;BA.debugLine="End Sub";
return "";
}
public static String  _xyzbuttonn1_click() throws Exception{
 //BA.debugLineNum = 240;BA.debugLine="Private Sub xyzButtonN1_Click";
 //BA.debugLineNum = 245;BA.debugLine="toast.Show($\"B4X [b]xyzButtonN7 [/b] \"$ & xyzButt";
_toast._show /*void*/ (("B4X [b]xyzButtonN7 [/b] ")+BA.ObjectToString(_xyzbuttonn1._gettag /*Object*/ ()));
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public static String  _xyzbuttonn7_click() throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Private Sub xyzButtonN7_Click";
 //BA.debugLineNum = 251;BA.debugLine="toast.Show($\"B4X [b]xyzButtonN7 [/b] \"$ & xyzButt";
_toast._show /*void*/ (("B4X [b]xyzButtonN7 [/b] ")+BA.ObjectToString(_xyzbuttonn7._gettag /*Object*/ ()));
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
}
