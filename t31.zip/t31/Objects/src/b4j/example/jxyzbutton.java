package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class jxyzbutton extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.jxyzbutton", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.jxyzbutton.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _mbase = null;
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _mparent = null;
public anywheresoftware.b4j.objects.LabelWrapper _mlabel = null;
public Object _mtag = null;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public String _mtext = "";
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mtextcolor = null;
public String _mtextalignment = "";
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mpressedcolor = null;
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mbackgroundcolor = null;
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mbordercolor = null;
public int _mborderwidth = 0;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _parent,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Public Sub AddToParent(Parent As Pane,  Props As M";
 //BA.debugLineNum = 95;BA.debugLine="Log(\"jxyzButton  AddToParent ==>\")";
__c.LogImpl("619857409","jxyzButton  AddToParent ==>",0);
 //BA.debugLineNum = 96;BA.debugLine="Log(\"TextAlignment= \"&Props.Get(\"TextAlignment\"))";
__c.LogImpl("619857410","TextAlignment= "+BA.ObjectToString(_props.Get((Object)("TextAlignment"))),0);
 //BA.debugLineNum = 98;BA.debugLine="mParent = Parent";
_mparent = _parent;
 //BA.debugLineNum = 100;BA.debugLine="mLeft = Props.Get(\"Left\")";
_mleft = (int)(BA.ObjectToNumber(_props.Get((Object)("Left"))));
 //BA.debugLineNum = 101;BA.debugLine="mTop = Props.Get(\"Top\")";
_mtop = (int)(BA.ObjectToNumber(_props.Get((Object)("Top"))));
 //BA.debugLineNum = 102;BA.debugLine="mWidth = Props.Get(\"Width\")";
_mwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("Width"))));
 //BA.debugLineNum = 103;BA.debugLine="mHeight = Props.Get(\"Height\")";
_mheight = (int)(BA.ObjectToNumber(_props.Get((Object)("Height"))));
 //BA.debugLineNum = 105;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 106;BA.debugLine="mTextColor = Props.Get(\"TextColor\")";
_mtextcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("TextColor"))));
 //BA.debugLineNum = 107;BA.debugLine="mTextAlignment = Props.Get(\"TextAlignment\")";
_mtextalignment = BA.ObjectToString(_props.Get((Object)("TextAlignment")));
 //BA.debugLineNum = 108;BA.debugLine="mBackgroundColor = Props.Get(\"BackgroundColor\")";
_mbackgroundcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BackgroundColor"))));
 //BA.debugLineNum = 109;BA.debugLine="mPressedColor = Props.Get(\"PressedColor\")";
_mpressedcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("PressedColor"))));
 //BA.debugLineNum = 110;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 111;BA.debugLine="mBorderColor = Props.Get(\"BorderColor\")";
_mbordercolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BorderColor"))));
 //BA.debugLineNum = 112;BA.debugLine="mTag = Props.Get(\"Tag\")";
_mtag = _props.Get((Object)("Tag"));
 //BA.debugLineNum = 114;BA.debugLine="mBase.Initialize(\"mBase\")";
_mbase.Initialize(ba,"mBase");
 //BA.debugLineNum = 115;BA.debugLine="mParent.AddNode(mBase, mLeft, mTop, mWidth, mHeig";
_mparent.AddNode((javafx.scene.Node)(_mbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 117;BA.debugLine="CSSUtils.SetBackgroundColor(mBase , mBackgroundCo";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mbackgroundcolor);
 //BA.debugLineNum = 118;BA.debugLine="CSSUtils.SetBorder(mBase , mBorderWidth ,mBorderC";
_cssutils._setborder((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mborderwidth,_mbordercolor,0);
 //BA.debugLineNum = 120;BA.debugLine="InitClass";
_initclass();
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 143;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 144;BA.debugLine="Log(\"jxyzButton  Base_Resize ==>\")";
__c.LogImpl("619988481","jxyzButton  Base_Resize ==>",0);
 //BA.debugLineNum = 146;BA.debugLine="mWidth = Width";
_mwidth = (int) (_width);
 //BA.debugLineNum = 147;BA.debugLine="mHeight = Height";
_mheight = (int) (_height);
 //BA.debugLineNum = 148;BA.debugLine="mBase.PrefWidth = mWidth";
_mbase.setPrefWidth(_mwidth);
 //BA.debugLineNum = 149;BA.debugLine="mBase.PrefHeight = mHeight";
_mbase.setPrefHeight(_mheight);
 //BA.debugLineNum = 151;BA.debugLine="Log(\"手冊上有講.說這邊要加入InitClass\")";
__c.LogImpl("619988488","手冊上有講.說這邊要加入InitClass",0);
 //BA.debugLineNum = 152;BA.debugLine="InitClass	'Base_Resize 手冊上有講.說這邊要加入";
_initclass();
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 18;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 19;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 20;BA.debugLine="Private mBase As Pane";
_mbase = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private mParent As Pane";
_mparent = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private mLabel As Label";
_mlabel = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private  mTag As Object		'不懂為何宣告物件???";
_mtag = new Object();
 //BA.debugLineNum = 26;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 28;BA.debugLine="Private mText As String";
_mtext = "";
 //BA.debugLineNum = 29;BA.debugLine="Private mTextColor As Paint";
_mtextcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private mTextAlignment As String";
_mtextalignment = "";
 //BA.debugLineNum = 33;BA.debugLine="Private mPressedColor, mBackgroundColor ,mBorderC";
_mpressedcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
_mbackgroundcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
_mbordercolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private mBorderWidth  As Int";
_mborderwidth = 0;
 //BA.debugLineNum = 35;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Public Sub DesignerCreateView (Base As Pane, Lbl A";
 //BA.debugLineNum = 51;BA.debugLine="Log(\"jxyzButton DesignerCreateView==>\")";
__c.LogImpl("619791873","jxyzButton DesignerCreateView==>",0);
 //BA.debugLineNum = 52;BA.debugLine="Log(\"TextAlignment= \"&Props.Get(\"TextAlignment\"))";
__c.LogImpl("619791874","TextAlignment= "+BA.ObjectToString(_props.Get((Object)("TextAlignment"))),0);
 //BA.debugLineNum = 54;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("619791876","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 60;BA.debugLine="Try";
try { //BA.debugLineNum = 61;BA.debugLine="mParent = Base.Parent";
_mparent = (anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_base.getParent().getObject()));
 //BA.debugLineNum = 63;BA.debugLine="mLeft = Base.Left";
_mleft = (int) (_base.getLeft());
 //BA.debugLineNum = 64;BA.debugLine="mTop = Base.Top";
_mtop = (int) (_base.getTop());
 //BA.debugLineNum = 65;BA.debugLine="mWidth = Base.Width";
_mwidth = (int) (_base.getWidth());
 //BA.debugLineNum = 66;BA.debugLine="mHeight = Base.Height";
_mheight = (int) (_base.getHeight());
 //BA.debugLineNum = 68;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 69;BA.debugLine="mTextColor = Lbl.TextColor";
_mtextcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_lbl.getTextColor()));
 //BA.debugLineNum = 70;BA.debugLine="mTextAlignment = Props.Get(\"TextAlignment\")";
_mtextalignment = BA.ObjectToString(_props.Get((Object)("TextAlignment")));
 //BA.debugLineNum = 71;BA.debugLine="mBackgroundColor = Props.Get(\"BackgroundColor\")";
_mbackgroundcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BackgroundColor"))));
 //BA.debugLineNum = 72;BA.debugLine="mPressedColor = Props.Get(\"PressedColor\")";
_mpressedcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("PressedColor"))));
 //BA.debugLineNum = 73;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 74;BA.debugLine="mBorderColor = Props.Get(\"BorderColor\")";
_mbordercolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BorderColor"))));
 //BA.debugLineNum = 76;BA.debugLine="mTag = Base.Tag";
_mtag = _base.getTag();
 //BA.debugLineNum = 80;BA.debugLine="mBase.Initialize(\"mBase\")";
_mbase.Initialize(ba,"mBase");
 //BA.debugLineNum = 81;BA.debugLine="mParent.AddNode(mBase, mLeft, mTop, mWidth, mHei";
_mparent.AddNode((javafx.scene.Node)(_mbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 84;BA.debugLine="CSSUtils.SetBackgroundColor(mBase , mBackgroundC";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mbackgroundcolor);
 //BA.debugLineNum = 85;BA.debugLine="CSSUtils.SetBorder(mBase , mBorderWidth ,mBorder";
_cssutils._setborder((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mborderwidth,_mbordercolor,0);
 } 
       catch (Exception e23) {
			ba.setLastException(e23); //BA.debugLineNum = 87;BA.debugLine="Log(LastException)";
__c.LogImpl("619791909",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper  _getbase() throws Exception{
 //BA.debugLineNum = 192;BA.debugLine="Public Sub GetBase As Pane";
 //BA.debugLineNum = 193;BA.debugLine="Return mBase";
if (true) return _mbase;
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4j.objects.JFX.PaintWrapper  _getpressedcolor() throws Exception{
 //BA.debugLineNum = 211;BA.debugLine="Public Sub getPressedColor  As Paint";
 //BA.debugLineNum = 212;BA.debugLine="Return mPressedColor";
if (true) return _mpressedcolor;
 //BA.debugLineNum = 213;BA.debugLine="End Sub";
return null;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 202;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 203;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 204;BA.debugLine="End Sub";
return null;
}
public String  _gettextalignment() throws Exception{
 //BA.debugLineNum = 220;BA.debugLine="Public Sub getTextAlignment  As String";
 //BA.debugLineNum = 221;BA.debugLine="Return mTextAlignment";
if (true) return _mtextalignment;
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
return "";
}
public String  _initclass() throws Exception{
 //BA.debugLineNum = 123;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 124;BA.debugLine="Log(\"jxyzButton  InitClass ==>\")";
__c.LogImpl("619922945","jxyzButton  InitClass ==>",0);
 //BA.debugLineNum = 128;BA.debugLine="mLabel.Initialize(\"\")";
_mlabel.Initialize(ba,"");
 //BA.debugLineNum = 130;BA.debugLine="mLabel.Text = mText";
_mlabel.setText(_mtext);
 //BA.debugLineNum = 131;BA.debugLine="mLabel.TextSize = 28																		'B4J, B4A";
_mlabel.setTextSize(28);
 //BA.debugLineNum = 132;BA.debugLine="mLabel.TextColor = mTextColor";
_mlabel.setTextColor((javafx.scene.paint.Paint)(_mtextcolor.getObject()));
 //BA.debugLineNum = 133;BA.debugLine="mLabel.Alignment = mTextAlignment";
_mlabel.setAlignment(_mtextalignment);
 //BA.debugLineNum = 136;BA.debugLine="mBase.AddNode(mLabel, 0, 0, mWidth, mHeight)	'B4J";
_mbase.AddNode((javafx.scene.Node)(_mlabel.getObject()),0,0,_mwidth,_mheight);
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 41;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 42;BA.debugLine="Log(\"========================>\")";
__c.LogImpl("619726337","========================>",0);
 //BA.debugLineNum = 43;BA.debugLine="Log(\"jxyzButton  Initialize ==>\")";
__c.LogImpl("619726338","jxyzButton  Initialize ==>",0);
 //BA.debugLineNum = 44;BA.debugLine="Log(\"EventName= \"&EventName)";
__c.LogImpl("619726339","EventName= "+_eventname,0);
 //BA.debugLineNum = 46;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 47;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public String  _mbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 155;BA.debugLine="Private Sub mBase_Touch (Action As Int, X As Doubl";
 //BA.debugLineNum = 156;BA.debugLine="Log(\"jxyzButton  mBase_Touch==>\")";
__c.LogImpl("620119553","jxyzButton  mBase_Touch==>",0);
 //BA.debugLineNum = 157;BA.debugLine="Log( Action)";
__c.LogImpl("620119554",BA.NumberToString(_action),0);
 //BA.debugLineNum = 159;BA.debugLine="Select Action";
switch (_action) {
case 0: {
 //BA.debugLineNum = 162;BA.debugLine="CSSUtils.SetBackgroundColor(mBase , mPressedCol";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mpressedcolor);
 break; }
case 2: {
 break; }
case 1: {
 //BA.debugLineNum = 166;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\")";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 167;BA.debugLine="CallSub(mCallBack,  mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 171;BA.debugLine="CSSUtils.SetBackgroundColor(mBase , mBackground";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbase.getObject())),_mbackgroundcolor);
 break; }
}
;
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return "";
}
public String  _setpressedcolor(anywheresoftware.b4j.objects.JFX.PaintWrapper _pressedcolor) throws Exception{
 //BA.debugLineNum = 207;BA.debugLine="Public Sub setPressedColor(PressedColor  As Paint)";
 //BA.debugLineNum = 208;BA.debugLine="mPressedColor = PressedColor";
_mpressedcolor = _pressedcolor;
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 197;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 198;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 199;BA.debugLine="mBase.Tag = Tag";
_mbase.setTag(_tag);
 //BA.debugLineNum = 200;BA.debugLine="End Sub";
return "";
}
public String  _settextalignment(String _s1) throws Exception{
 //BA.debugLineNum = 215;BA.debugLine="Public Sub setTextAlignment(s1  As String)";
 //BA.debugLineNum = 216;BA.debugLine="mTextAlignment = s1";
_mtextalignment = _s1;
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public String  _ss1() throws Exception{
 //BA.debugLineNum = 224;BA.debugLine="Public Sub ss1";
 //BA.debugLineNum = 226;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
