package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzbuttonn extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzbuttonn", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzbuttonn.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xtemp = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xparent = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbutton = null;
public anywheresoftware.b4j.objects.LabelWrapper _mbutton = null;
public Object _mtag = null;
public String _mtext = "";
public int _mtextcolor = 0;
public double _mlabeltextsize = 0;
public int _mpressedcolor = 0;
public int _mbackgroundcolor = 0;
public int _mborderwidth = 0;
public int _mbordercolor = 0;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(Object _parent,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Public Sub AddToParent(Parent As Object,  Props As";
 //BA.debugLineNum = 116;BA.debugLine="Log(\"xyzButtonN  AddToParent ==>\")";
__c.LogImpl("616515073","xyzButtonN  AddToParent ==>",0);
 //BA.debugLineNum = 119;BA.debugLine="b4xParent = Parent";
_b4xparent = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_parent));
 //BA.debugLineNum = 121;BA.debugLine="Try	'傳入的參數.有可能出錯???";
try { //BA.debugLineNum = 122;BA.debugLine="mLeft = Props.Get(\"Left\")";
_mleft = (int)(BA.ObjectToNumber(_props.Get((Object)("Left"))));
 //BA.debugLineNum = 123;BA.debugLine="mTop = Props.Get(\"Top\")";
_mtop = (int)(BA.ObjectToNumber(_props.Get((Object)("Top"))));
 //BA.debugLineNum = 124;BA.debugLine="mWidth = Props.Get(\"Width\")";
_mwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("Width"))));
 //BA.debugLineNum = 125;BA.debugLine="mHeight = Props.Get(\"Height\")";
_mheight = (int)(BA.ObjectToNumber(_props.Get((Object)("Height"))));
 //BA.debugLineNum = 127;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 128;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Props.Get(\"";
_mtextcolor = _xui.PaintOrColorToColor(_props.Get((Object)("TextColor")));
 //BA.debugLineNum = 129;BA.debugLine="mTag = Props.Get(\"Tag\")";
_mtag = _props.Get((Object)("Tag"));
 //BA.debugLineNum = 130;BA.debugLine="mPressedColor = xui.PaintOrColorToColor(Props.Ge";
_mpressedcolor = _xui.PaintOrColorToColor(_props.Get((Object)("PressedColor")));
 //BA.debugLineNum = 131;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 132;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 133;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 136;BA.debugLine="Log(\"xyzButtonN AddToParent= \"&LastException)";
__c.LogImpl("616515093","xyzButtonN AddToParent= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 140;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 142;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 143;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 145;BA.debugLine="Log(\"xyzButtonN= \"&b4xBase.Top )";
__c.LogImpl("616515102","xyzButtonN= "+BA.NumberToString(_b4xbase.getTop()),0);
 //BA.debugLineNum = 147;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public String  _b4xbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 198;BA.debugLine="Private Sub b4xBase_Touch (Action As Int, X As Dou";
 //BA.debugLineNum = 199;BA.debugLine="Log(\"xyzButtonN  b4xBase_Touch==>\")";
__c.LogImpl("616646145","xyzButtonN  b4xBase_Touch==>",0);
 //BA.debugLineNum = 200;BA.debugLine="Log( Action)";
__c.LogImpl("616646146",BA.NumberToString(_action),0);
 //BA.debugLineNum = 202;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_b4xbase.TOUCH_ACTION_DOWN,_b4xbase.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 204;BA.debugLine="b4xBase.Color = mPressedColor";
_b4xbase.setColor(_mpressedcolor);
 break; }
case 1: {
 //BA.debugLineNum = 208;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Clic";
if (_xui.SubExists(ba,_mcallback,_meventname+"_Click",(int) (0))) { 
 //BA.debugLineNum = 209;BA.debugLine="CallSubDelayed(mCallBack, mEventName & \"_Click\")";
__c.CallSubDelayed(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 211;BA.debugLine="b4xBase.Color = mBackgroundColor";
_b4xbase.setColor(_mbackgroundcolor);
 break; }
}
;
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 182;BA.debugLine="Log(\"xyzButtonN  Base_Resize ==>\")";
__c.LogImpl("623003137","xyzButtonN  Base_Resize ==>",0);
 //BA.debugLineNum = 183;BA.debugLine="Log(\"xyzButtonN  Width= \"&Width)";
__c.LogImpl("623003138","xyzButtonN  Width= "+BA.NumberToString(_width),0);
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 20;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 21;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 23;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 25;BA.debugLine="Private b4xTemp As B4XView";
_b4xtemp = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private b4xBase As B4XView";
_b4xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private b4xParent As B4XView";
_b4xparent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private b4xButton As B4XView";
_b4xbutton = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private mButton As Label";
_mbutton = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private  mTag As Object		'不懂為何宣告物件???";
_mtag = new Object();
 //BA.debugLineNum = 36;BA.debugLine="Private mText As String";
_mtext = "";
 //BA.debugLineNum = 37;BA.debugLine="Private mTextColor As Int";
_mtextcolor = 0;
 //BA.debugLineNum = 38;BA.debugLine="Private mLabelTextSize As Double";
_mlabeltextsize = 0;
 //BA.debugLineNum = 40;BA.debugLine="Private mPressedColor, mBackgroundColor As Int";
_mpressedcolor = 0;
_mbackgroundcolor = 0;
 //BA.debugLineNum = 41;BA.debugLine="Private mBorderWidth ,mBorderColor As Int";
_mborderwidth = 0;
_mbordercolor = 0;
 //BA.debugLineNum = 42;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 70;BA.debugLine="Log(\"xyzButtonN DesignerCreateView==>\")";
__c.LogImpl("616449537","xyzButtonN DesignerCreateView==>",0);
 //BA.debugLineNum = 72;BA.debugLine="Log(\"test1\")";
__c.LogImpl("616449539","test1",0);
 //BA.debugLineNum = 73;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("616449540","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 76;BA.debugLine="b4xTemp = Base				'照論壇上的範例.Base當作暫時的物件";
_b4xtemp = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 79;BA.debugLine="b4xTemp.Visible = False		'我把它隱藏起來.安心";
_b4xtemp.setVisible(__c.False);
 //BA.debugLineNum = 81;BA.debugLine="mLeft = b4xTemp.Left";
_mleft = (int) (_b4xtemp.getLeft());
 //BA.debugLineNum = 82;BA.debugLine="mTop = b4xTemp.Top";
_mtop = (int) (_b4xtemp.getTop());
 //BA.debugLineNum = 83;BA.debugLine="mWidth = b4xTemp.Width";
_mwidth = (int) (_b4xtemp.getWidth());
 //BA.debugLineNum = 84;BA.debugLine="mHeight = b4xTemp.Height";
_mheight = (int) (_b4xtemp.getHeight());
 //BA.debugLineNum = 85;BA.debugLine="mTag = b4xTemp.Tag				'利用原有的屬性.不須另外設定";
_mtag = _b4xtemp.getTag();
 //BA.debugLineNum = 87;BA.debugLine="Try";
try { //BA.debugLineNum = 88;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 89;BA.debugLine="mTextColor = xui.PaintOrColorToColor(Lbl.TextCol";
_mtextcolor = _xui.PaintOrColorToColor((Object)(_lbl.getTextColor()));
 //BA.debugLineNum = 90;BA.debugLine="mPressedColor = xui.PaintOrColorToColor(Props.Ge";
_mpressedcolor = _xui.PaintOrColorToColor(_props.Get((Object)("PressedColor")));
 //BA.debugLineNum = 91;BA.debugLine="mBackgroundColor = xui.PaintOrColorToColor(Props";
_mbackgroundcolor = _xui.PaintOrColorToColor(_props.Get((Object)("BackgroundColor")));
 //BA.debugLineNum = 92;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 93;BA.debugLine="mBorderColor = xui.PaintOrColorToColor(Props.Get";
_mbordercolor = _xui.PaintOrColorToColor(_props.Get((Object)("BorderColor")));
 } 
       catch (Exception e19) {
			ba.setLastException(e19); //BA.debugLineNum = 96;BA.debugLine="Log(\"xyzButtonN DesignerCreateView= \"&LastExcept";
__c.LogImpl("616449563","xyzButtonN DesignerCreateView= "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 100;BA.debugLine="b4xBase = xui.CreatePanel(\"b4xBase\")	'這個是手動建立一個Pa";
_b4xbase = _xui.CreatePanel(ba,"b4xBase");
 //BA.debugLineNum = 101;BA.debugLine="b4xBase.SetColorAndBorder(mBackgroundColor ,  mBo";
_b4xbase.SetColorAndBorder(_mbackgroundcolor,_mborderwidth,_mbordercolor,__c.DipToCurrent((int) (0)));
 //BA.debugLineNum = 105;BA.debugLine="b4xParent = b4xTemp.Parent";
_b4xparent = _b4xtemp.getParent();
 //BA.debugLineNum = 106;BA.debugLine="b4xParent.AddView(b4xBase, mLeft, mTop, mWidth, m";
_b4xparent.AddView((javafx.scene.Node)(_b4xbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 110;BA.debugLine="InitClass	'在b4xBase基礎上建一個B4xLabel物件";
_initclass();
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public int  _getbackgroundcolor() throws Exception{
 //BA.debugLineNum = 283;BA.debugLine="Public Sub getBackgroundColor  As Int";
 //BA.debugLineNum = 284;BA.debugLine="Return mBackgroundColor";
if (true) return _mbackgroundcolor;
 //BA.debugLineNum = 285;BA.debugLine="End Sub";
return 0;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 250;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return null;
}
public String  _gettext() throws Exception{
 //BA.debugLineNum = 264;BA.debugLine="Public Sub getText  As String";
 //BA.debugLineNum = 265;BA.debugLine="Return mText";
if (true) return _mtext;
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public int  _gettop() throws Exception{
 //BA.debugLineNum = 287;BA.debugLine="Public Sub getTop  As Int";
 //BA.debugLineNum = 288;BA.debugLine="Return mTop";
if (true) return _mtop;
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return 0;
}
public String  _initclass() throws Exception{
int _lblwidth = 0;
 //BA.debugLineNum = 151;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 152;BA.debugLine="Log(\"xyzButtonN  InitClass ==>\")";
__c.LogImpl("616580609","xyzButtonN  InitClass ==>",0);
 //BA.debugLineNum = 155;BA.debugLine="Private  lblWidth  As Int";
_lblwidth = 0;
 //BA.debugLineNum = 156;BA.debugLine="lblWidth = 2 * mHeight / 3		'icon Label width and";
_lblwidth = (int) (2*_mheight/(double)3);
 //BA.debugLineNum = 159;BA.debugLine="mLabelTextSize = lblWidth / 3 / xui.Scale";
_mlabeltextsize = _lblwidth/(double)3/(double)_xui.getScale();
 //BA.debugLineNum = 162;BA.debugLine="mButton.Initialize(\"\")";
_mbutton.Initialize(ba,"");
 //BA.debugLineNum = 163;BA.debugLine="b4xButton = mButton";
_b4xbutton = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_mbutton.getObject()));
 //BA.debugLineNum = 164;BA.debugLine="b4xButton.SetTextAlignment(\"CENTER\", \"CENTER\")";
_b4xbutton.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 166;BA.debugLine="b4xButton.TextSize = mLabelTextSize";
_b4xbutton.setTextSize(_mlabeltextsize);
 //BA.debugLineNum = 167;BA.debugLine="b4xButton.TextColor = xui.PaintOrColorToColor(mTe";
_b4xbutton.setTextColor(_xui.PaintOrColorToColor((Object)(_mtextcolor)));
 //BA.debugLineNum = 171;BA.debugLine="b4xButton.Text = mText";
_b4xbutton.setText(_mtext);
 //BA.debugLineNum = 175;BA.debugLine="b4xBase.AddView(b4xButton , 0, 0 , b4xBase.Width";
_b4xbase.AddView((javafx.scene.Node)(_b4xbutton.getObject()),0,0,_b4xbase.getWidth(),_b4xbase.getHeight());
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 46;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 47;BA.debugLine="Log(\"========================>\")";
__c.LogImpl("616384001","========================>",0);
 //BA.debugLineNum = 48;BA.debugLine="Log(\"xyzButtonN  Initialize ==>\")";
__c.LogImpl("616384002","xyzButtonN  Initialize ==>",0);
 //BA.debugLineNum = 49;BA.debugLine="Log(\"EventName= \"&EventName)";
__c.LogImpl("616384003","EventName= "+_eventname,0);
 //BA.debugLineNum = 51;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 52;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 54;BA.debugLine="mText = \"\"";
_mtext = "";
 //BA.debugLineNum = 56;BA.debugLine="mTextColor = xui.Color_Cyan";
_mtextcolor = _xui.Color_Cyan;
 //BA.debugLineNum = 61;BA.debugLine="mPressedColor = xui.Color_Yellow";
_mpressedcolor = _xui.Color_Yellow;
 //BA.debugLineNum = 63;BA.debugLine="mBackgroundColor = xui.Color_Transparent";
_mbackgroundcolor = _xui.Color_Transparent;
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _setbackgroundcolor(int _s1) throws Exception{
 //BA.debugLineNum = 277;BA.debugLine="Public Sub setBackgroundColor(s1 As Int)";
 //BA.debugLineNum = 278;BA.debugLine="Log(\"setBackgroundColor ==>\")";
__c.LogImpl("617039361","setBackgroundColor ==>",0);
 //BA.debugLineNum = 280;BA.debugLine="mBackgroundColor=s1";
_mbackgroundcolor = _s1;
 //BA.debugLineNum = 281;BA.debugLine="If b4xBase.IsInitialized Then b4xBase.Color = mBa";
if (_b4xbase.IsInitialized()) { 
_b4xbase.setColor(_mbackgroundcolor);};
 //BA.debugLineNum = 282;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 244;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 245;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 246;BA.debugLine="b4xBase.Tag = Tag";
_b4xbase.setTag(_tag);
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public String  _settext(String _s1) throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Public Sub setText(s1 As String)";
 //BA.debugLineNum = 254;BA.debugLine="Log(\"setText ==>\")";
__c.LogImpl("616842753","setText ==>",0);
 //BA.debugLineNum = 258;BA.debugLine="mText=s1";
_mtext = _s1;
 //BA.debugLineNum = 259;BA.debugLine="b4xButton.Text = s1";
_b4xbutton.setText(_s1);
 //BA.debugLineNum = 262;BA.debugLine="End Sub";
return "";
}
public String  _settextalignment(String _s1,String _s2) throws Exception{
 //BA.debugLineNum = 292;BA.debugLine="Public Sub SetTextAlignment(s1 As String,s2 As Str";
 //BA.debugLineNum = 294;BA.debugLine="b4xButton.SetTextAlignment(s1 , s2 )";
_b4xbutton.SetTextAlignment(_s1,_s2);
 //BA.debugLineNum = 295;BA.debugLine="End Sub";
return "";
}
public String  _settextcolor(int _s1) throws Exception{
 //BA.debugLineNum = 269;BA.debugLine="Public Sub setTextColor(s1 As Int)";
 //BA.debugLineNum = 270;BA.debugLine="Log(\"setTextColor ==>\")";
__c.LogImpl("616973825","setTextColor ==>",0);
 //BA.debugLineNum = 272;BA.debugLine="mTextColor=s1";
_mtextcolor = _s1;
 //BA.debugLineNum = 273;BA.debugLine="b4xButton.TextColor = mTextColor";
_b4xbutton.setTextColor(_mtextcolor);
 //BA.debugLineNum = 274;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
