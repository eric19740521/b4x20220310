package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class jxyzbuttonn extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.jxyzbuttonn", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.jxyzbuttonn.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _mbase = null;
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _mparent = null;
public anywheresoftware.b4j.objects.ButtonWrapper _mbutton = null;
public Object _mtag = null;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public String _mtext = "";
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mtextcolor = null;
public String _mtextalignment = "";
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mpressedcolor = null;
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mbackgroundcolor = null;
public anywheresoftware.b4j.objects.JFX.PaintWrapper _mbordercolor = null;
public int _mborderwidth = 0;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _addtoparent(anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _parent,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Public Sub AddToParent(Parent As Pane,  Props As M";
 //BA.debugLineNum = 93;BA.debugLine="Log(\"jxyzButtonN  AddToParent ==>\")";
__c.LogImpl("621364737","jxyzButtonN  AddToParent ==>",0);
 //BA.debugLineNum = 94;BA.debugLine="Log(\"TextAlignment= \"&Props.Get(\"TextAlignment\"))";
__c.LogImpl("621364738","TextAlignment= "+BA.ObjectToString(_props.Get((Object)("TextAlignment"))),0);
 //BA.debugLineNum = 96;BA.debugLine="mParent = Parent";
_mparent = _parent;
 //BA.debugLineNum = 98;BA.debugLine="mLeft = Props.Get(\"Left\")";
_mleft = (int)(BA.ObjectToNumber(_props.Get((Object)("Left"))));
 //BA.debugLineNum = 99;BA.debugLine="mTop = Props.Get(\"Top\")";
_mtop = (int)(BA.ObjectToNumber(_props.Get((Object)("Top"))));
 //BA.debugLineNum = 100;BA.debugLine="mWidth = Props.Get(\"Width\")";
_mwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("Width"))));
 //BA.debugLineNum = 101;BA.debugLine="mHeight = Props.Get(\"Height\")";
_mheight = (int)(BA.ObjectToNumber(_props.Get((Object)("Height"))));
 //BA.debugLineNum = 103;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 104;BA.debugLine="mTextColor = Props.Get(\"TextColor\")";
_mtextcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("TextColor"))));
 //BA.debugLineNum = 105;BA.debugLine="mTextAlignment = Props.Get(\"TextAlignment\")";
_mtextalignment = BA.ObjectToString(_props.Get((Object)("TextAlignment")));
 //BA.debugLineNum = 106;BA.debugLine="mBackgroundColor = Props.Get(\"BackgroundColor\")";
_mbackgroundcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BackgroundColor"))));
 //BA.debugLineNum = 107;BA.debugLine="mPressedColor = Props.Get(\"PressedColor\")";
_mpressedcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("PressedColor"))));
 //BA.debugLineNum = 108;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 109;BA.debugLine="mBorderColor = Props.Get(\"BorderColor\")";
_mbordercolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BorderColor"))));
 //BA.debugLineNum = 110;BA.debugLine="mTag = Props.Get(\"Tag\")";
_mtag = _props.Get((Object)("Tag"));
 //BA.debugLineNum = 112;BA.debugLine="mBase.Initialize(\"mBase\")";
_mbase.Initialize(ba,"mBase");
 //BA.debugLineNum = 113;BA.debugLine="mParent.AddNode(mBase, mLeft, mTop, mWidth, mHeig";
_mparent.AddNode((javafx.scene.Node)(_mbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 //BA.debugLineNum = 118;BA.debugLine="InitClass";
_initclass();
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 141;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 142;BA.debugLine="Log(\"jxyzButtonN  Base_Resize ==>\")";
__c.LogImpl("621233665","jxyzButtonN  Base_Resize ==>",0);
 //BA.debugLineNum = 144;BA.debugLine="mWidth = Width";
_mwidth = (int) (_width);
 //BA.debugLineNum = 145;BA.debugLine="mHeight = Height";
_mheight = (int) (_height);
 //BA.debugLineNum = 146;BA.debugLine="mBase.PrefWidth = mWidth";
_mbase.setPrefWidth(_mwidth);
 //BA.debugLineNum = 147;BA.debugLine="mBase.PrefHeight = mHeight";
_mbase.setPrefHeight(_mheight);
 //BA.debugLineNum = 149;BA.debugLine="Log(\"手冊上有講.說這邊要加入InitClass\")";
__c.LogImpl("621233672","手冊上有講.說這邊要加入InitClass",0);
 //BA.debugLineNum = 150;BA.debugLine="InitClass	'Base_Resize 手冊上有講.說這邊要加入";
_initclass();
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
return "";
}
public String  _base_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Private Sub Base_Touch (Action As Int, X As Double";
 //BA.debugLineNum = 155;BA.debugLine="Log(\"jxyzButtonN  Base_Touch==>\")";
__c.LogImpl("622675457","jxyzButtonN  Base_Touch==>",0);
 //BA.debugLineNum = 156;BA.debugLine="Log( Action)";
__c.LogImpl("622675458",BA.NumberToString(_action),0);
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 18;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 19;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 20;BA.debugLine="Private mBase As Pane";
_mbase = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private mParent As Pane";
_mparent = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private mButton As Button";
_mbutton = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private  mTag As Object		'不懂為何宣告物件???";
_mtag = new Object();
 //BA.debugLineNum = 26;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 28;BA.debugLine="Private mText As String";
_mtext = "";
 //BA.debugLineNum = 29;BA.debugLine="Private mTextColor As Paint";
_mtextcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private mTextAlignment As String";
_mtextalignment = "";
 //BA.debugLineNum = 33;BA.debugLine="Private mPressedColor, mBackgroundColor ,mBorderC";
_mpressedcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
_mbackgroundcolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
_mbordercolor = new anywheresoftware.b4j.objects.JFX.PaintWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private mBorderWidth  As Int";
_mborderwidth = 0;
 //BA.debugLineNum = 35;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Public Sub DesignerCreateView (Base As Pane, Lbl A";
 //BA.debugLineNum = 50;BA.debugLine="Log(\"jxyzButtonN DesignerCreateView==>\")";
__c.LogImpl("621168129","jxyzButtonN DesignerCreateView==>",0);
 //BA.debugLineNum = 51;BA.debugLine="Log(\"TextAlignment= \"&Props.Get(\"TextAlignment\"))";
__c.LogImpl("621168130","TextAlignment= "+BA.ObjectToString(_props.Get((Object)("TextAlignment"))),0);
 //BA.debugLineNum = 53;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("621168132","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 59;BA.debugLine="Try";
try { //BA.debugLineNum = 60;BA.debugLine="mParent = Base.Parent";
_mparent = (anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_base.getParent().getObject()));
 //BA.debugLineNum = 62;BA.debugLine="mLeft = Base.Left";
_mleft = (int) (_base.getLeft());
 //BA.debugLineNum = 63;BA.debugLine="mTop = Base.Top";
_mtop = (int) (_base.getTop());
 //BA.debugLineNum = 64;BA.debugLine="mWidth = Base.Width";
_mwidth = (int) (_base.getWidth());
 //BA.debugLineNum = 65;BA.debugLine="mHeight = Base.Height";
_mheight = (int) (_base.getHeight());
 //BA.debugLineNum = 67;BA.debugLine="mText = Props.Get(\"Text\")";
_mtext = BA.ObjectToString(_props.Get((Object)("Text")));
 //BA.debugLineNum = 68;BA.debugLine="mTextColor = Lbl.TextColor";
_mtextcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_lbl.getTextColor()));
 //BA.debugLineNum = 69;BA.debugLine="mTextAlignment = Props.Get(\"TextAlignment\")";
_mtextalignment = BA.ObjectToString(_props.Get((Object)("TextAlignment")));
 //BA.debugLineNum = 70;BA.debugLine="mBackgroundColor = Props.Get(\"BackgroundColor\")";
_mbackgroundcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BackgroundColor"))));
 //BA.debugLineNum = 71;BA.debugLine="mPressedColor = Props.Get(\"PressedColor\")";
_mpressedcolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("PressedColor"))));
 //BA.debugLineNum = 72;BA.debugLine="mBorderWidth = Props.Get(\"BorderWidth\")";
_mborderwidth = (int)(BA.ObjectToNumber(_props.Get((Object)("BorderWidth"))));
 //BA.debugLineNum = 73;BA.debugLine="mBorderColor = Props.Get(\"BorderColor\")";
_mbordercolor = (anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_props.Get((Object)("BorderColor"))));
 //BA.debugLineNum = 75;BA.debugLine="mTag = Base.Tag";
_mtag = _base.getTag();
 //BA.debugLineNum = 79;BA.debugLine="mBase.Initialize(\"mBase\")";
_mbase.Initialize(ba,"mBase");
 //BA.debugLineNum = 80;BA.debugLine="mParent.AddNode(mBase, mLeft, mTop, mWidth, mHei";
_mparent.AddNode((javafx.scene.Node)(_mbase.getObject()),_mleft,_mtop,_mwidth,_mheight);
 } 
       catch (Exception e21) {
			ba.setLastException(e21); //BA.debugLineNum = 86;BA.debugLine="Log(LastException)";
__c.LogImpl("621168165",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper  _getbase() throws Exception{
 //BA.debugLineNum = 214;BA.debugLine="Public Sub GetBase As Pane";
 //BA.debugLineNum = 215;BA.debugLine="Return mBase";
if (true) return _mbase;
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4j.objects.JFX.PaintWrapper  _getpressedcolor() throws Exception{
 //BA.debugLineNum = 233;BA.debugLine="Public Sub getPressedColor  As Paint";
 //BA.debugLineNum = 234;BA.debugLine="Return mPressedColor";
if (true) return _mpressedcolor;
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return null;
}
public Object  _gettag() throws Exception{
 //BA.debugLineNum = 224;BA.debugLine="Public Sub getTag As Object";
 //BA.debugLineNum = 225;BA.debugLine="Return mTag";
if (true) return _mtag;
 //BA.debugLineNum = 226;BA.debugLine="End Sub";
return null;
}
public String  _gettextalignment() throws Exception{
 //BA.debugLineNum = 242;BA.debugLine="Public Sub getTextAlignment  As String";
 //BA.debugLineNum = 243;BA.debugLine="Return mTextAlignment";
if (true) return _mtextalignment;
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _initclass() throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub InitClass";
 //BA.debugLineNum = 122;BA.debugLine="Log(\"jxyzButtonN  InitClass ==>\")";
__c.LogImpl("621430273","jxyzButtonN  InitClass ==>",0);
 //BA.debugLineNum = 126;BA.debugLine="mButton.Initialize(\"mButton\")";
_mbutton.Initialize(ba,"mButton");
 //BA.debugLineNum = 128;BA.debugLine="mButton.Text = mText";
_mbutton.setText(_mtext);
 //BA.debugLineNum = 129;BA.debugLine="mButton.TextSize = 28																		'B4J, B4A";
_mbutton.setTextSize(28);
 //BA.debugLineNum = 130;BA.debugLine="mButton.TextColor = mTextColor";
_mbutton.setTextColor((javafx.scene.paint.Paint)(_mtextcolor.getObject()));
 //BA.debugLineNum = 131;BA.debugLine="mButton.Alignment = mTextAlignment";
_mbutton.setAlignment(_mtextalignment);
 //BA.debugLineNum = 134;BA.debugLine="mBase.AddNode(mButton, 0, 0, mWidth, mHeight)	'B4";
_mbase.AddNode((javafx.scene.Node)(_mbutton.getObject()),0,0,_mwidth,_mheight);
 //BA.debugLineNum = 136;BA.debugLine="CSSUtils.SetBackgroundColor(mButton , mBackground";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mbackgroundcolor);
 //BA.debugLineNum = 137;BA.debugLine="CSSUtils.SetBorder(mButton , mBorderWidth ,mBorde";
_cssutils._setborder((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mborderwidth,_mbordercolor,0);
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 40;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 41;BA.debugLine="Log(\"========================>\")";
__c.LogImpl("621102593","========================>",0);
 //BA.debugLineNum = 42;BA.debugLine="Log(\"jxyzButtonN  Initialize ==>\")";
__c.LogImpl("621102594","jxyzButtonN  Initialize ==>",0);
 //BA.debugLineNum = 43;BA.debugLine="Log(\"EventName= \"&EventName)";
__c.LogImpl("621102595","EventName= "+_eventname,0);
 //BA.debugLineNum = 45;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 46;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _mbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 163;BA.debugLine="Private Sub mBase_Touch (Action As Int, X As Doubl";
 //BA.debugLineNum = 164;BA.debugLine="Log(\"jxyzButtonN  mBase_Touch==>\")";
__c.LogImpl("621495809","jxyzButtonN  mBase_Touch==>",0);
 //BA.debugLineNum = 165;BA.debugLine="Log( Action)";
__c.LogImpl("621495810",BA.NumberToString(_action),0);
 //BA.debugLineNum = 167;BA.debugLine="Select Action";
switch (_action) {
case 0: {
 //BA.debugLineNum = 170;BA.debugLine="CSSUtils.SetBackgroundColor(mButton , mPressedC";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mpressedcolor);
 break; }
case 2: {
 break; }
case 1: {
 //BA.debugLineNum = 174;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\")";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 175;BA.debugLine="CallSub(mCallBack,  mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 179;BA.debugLine="CSSUtils.SetBackgroundColor(mButton , mBackgrou";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mbackgroundcolor);
 break; }
}
;
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return "";
}
public String  _mbutton_click() throws Exception{
 //BA.debugLineNum = 185;BA.debugLine="Private Sub mButton_Click";
 //BA.debugLineNum = 186;BA.debugLine="Log(\"jxyzButtonN  mButton_Click==>\")";
__c.LogImpl("622478849","jxyzButtonN  mButton_Click==>",0);
 //BA.debugLineNum = 188;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 189;BA.debugLine="CallSub(mCallBack,  mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return "";
}
public String  _mbutton_mousepressed(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 198;BA.debugLine="Private Sub mButton_MousePressed (EventData As Mou";
 //BA.debugLineNum = 199;BA.debugLine="Log(\"jxyzButtonN  mButton_MousePressed==>\")";
__c.LogImpl("622872065","jxyzButtonN  mButton_MousePressed==>",0);
 //BA.debugLineNum = 201;BA.debugLine="CSSUtils.SetBackgroundColor(mButton , mPressedCol";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mpressedcolor);
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public String  _mbutton_mousereleased(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 203;BA.debugLine="Private Sub mButton_MouseReleased (EventData As Mo";
 //BA.debugLineNum = 204;BA.debugLine="Log(\"jxyzButtonN  mButton_MouseReleased==>\")";
__c.LogImpl("622937601","jxyzButtonN  mButton_MouseReleased==>",0);
 //BA.debugLineNum = 207;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 208;BA.debugLine="CallSub(mCallBack,  mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 //BA.debugLineNum = 210;BA.debugLine="CSSUtils.SetBackgroundColor(mButton , mBackgroun";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_mbutton.getObject())),_mbackgroundcolor);
 };
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public String  _setpressedcolor(anywheresoftware.b4j.objects.JFX.PaintWrapper _pressedcolor) throws Exception{
 //BA.debugLineNum = 229;BA.debugLine="Public Sub setPressedColor(PressedColor  As Paint)";
 //BA.debugLineNum = 230;BA.debugLine="mPressedColor = PressedColor";
_mpressedcolor = _pressedcolor;
 //BA.debugLineNum = 231;BA.debugLine="End Sub";
return "";
}
public String  _settag(Object _tag) throws Exception{
 //BA.debugLineNum = 219;BA.debugLine="Public Sub setTag(Tag As Object)";
 //BA.debugLineNum = 220;BA.debugLine="mTag = Tag";
_mtag = _tag;
 //BA.debugLineNum = 221;BA.debugLine="mBase.Tag = Tag";
_mbase.setTag(_tag);
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
return "";
}
public String  _settextalignment(String _s1) throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Public Sub setTextAlignment(s1  As String)";
 //BA.debugLineNum = 238;BA.debugLine="mTextAlignment = s1";
_mtextalignment = _s1;
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public String  _ss1() throws Exception{
 //BA.debugLineNum = 246;BA.debugLine="Public Sub ss1";
 //BA.debugLineNum = 248;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
